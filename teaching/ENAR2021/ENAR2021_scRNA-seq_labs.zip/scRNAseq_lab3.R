###################################################
##
## ENAR 2021 scRNA-seq short course lab 3.
##
## Clustering and Pseudotime-construction: Seurat, SC3, monocle3
##
## Prepared by Ziyi Li
##
###################################################

###################################
## pacakge installation
###################################
Sys.setenv(R_REMOTES_NO_ERRORS_FROM_WARNINGS=TRUE)
BiocManager::install("Seurat")
BiocManager::install("SC3")
 
# it took me a while to install monocle 3
if (!requireNamespace("BiocManager", quietly = TRUE))
    install.packages("BiocManager")
BiocManager::install(version = "3.10")
BiocManager::install(c('BiocGenerics', 'DelayedArray', 'DelayedMatrixStats',
                       'limma', 'S4Vectors', 'SingleCellExperiment',
                       'SummarizedExperiment', 'batchelor', 'Matrix.utils'))
install.packages("devtools")
devtools::install_github('cole-trapnell-lab/leidenbase')
devtools::install_github('cole-trapnell-lab/monocle3')
# installation troubleshooting page: https://cole-trapnell-lab.github.io/monocle3/docs/installation/

###################################
## Use Seg Pancreas data for clustering analysis
###################################
load("Seg_PancreasData.RData")

##############################
## Seurat
## tailored from https://satijalab.org/seurat/articles/pbmc3k_tutorial.html
##############################
library(dplyr)
library(Seurat)
library(patchwork)

# Initialize the Seurat object with the raw (non-normalized data)
Seg <- CreateSeuratObject(counts = Seg_counts, project = "Seg_Seurat", min.cells = 3, min.features = 10)

# With a full data, it helps to filter out low quality cells by percentage of mitochondrial genes
# Seg[["percent.mt"]] <- PercentageFeatureSet(Seg, pattern = "^MT-")

VlnPlot(Seg, features = c("nFeature_RNA", "nCount_RNA"), ncol = 2)

# Seurat has its own normalization procedure
Seg <- NormalizeData(Seg)

# Feature selection
Seg <- FindVariableFeatures(Seg, selection.method = "vst", nfeatures = 2000)

# Identify the 10 most highly variable genes
top10 <- head(VariableFeatures(Seg), 10)

# plot variable features with and without labels
plot1 <- VariableFeaturePlot(Seg)
plot2 <- LabelPoints(plot = plot1, points = top10, repel = TRUE)
plot2

# scale data with linear transformation
Seg <- ScaleData(Seg, features = rownames(Seg))

# dimension reduction
Seg <- RunPCA(Seg, features = VariableFeatures(object = Seg))
DimPlot(Seg, reduction = "pca")
DimHeatmap(Seg, dims = 1, cells = ncol(Seg_counts), balanced = TRUE)

# determine the dimensionality of the data
Seg <- JackStraw(Seg, num.replicate = 100)
Seg <- ScoreJackStraw(Seg, dims = 1:20)
JackStrawPlot(Seg, dims = 1:20)

ElbowPlot(Seg)

# cluster cells
Seg <- FindNeighbors(Seg, dims = 1:15)
Seg <- FindClusters(Seg, resolution = 0.1)  # larger resolution, finer the clusters
head(Idents(Seg))

# run tSNE
Seg <- RunTSNE(Seg, dims = 1:15)
DimPlot(Seg, reduction = "tsne")

# find cluster biomarkers
Seg.markers <- FindAllMarkers(Seg, only.pos = TRUE, min.pct = 0.25, logfc.threshold = 0.25)
Seg.markers %>% group_by(cluster) %>% top_n(n = 2)
VlnPlot(Seg, features = c("EGFL7", "FAP"))
FeaturePlot(Seg, features = c("EGFL7", "PPP1R15A", "FAP", "PPY", "DLK1", "SPP1"))
top10 <- Seg.markers %>% group_by(cluster) %>% top_n(n = 10)
DoHeatmap(Seg, features = top10$gene) + NoLegend()


new.cluster.ids <- c("alpha1", "alpha2", "alpha3", "gamma1", "beta1", "ductal", 
                     "beta2", "delta", "gamma2")
names(new.cluster.ids) <- levels(Seg)
Seg <- RenameIdents(Seg, new.cluster.ids)
P1 <- DimPlot(Seg, reduction = "tsne", label = TRUE, pt.size = 0.5) + NoLegend()

Idents(Seg) <- Seg_true_cell_label
P2 <- DimPlot(Seg, reduction = "tsne", label = TRUE, pt.size = 0.5) + NoLegend()
P1+P2

##############################
## SC3
## Tailored from https://bioconductor.org/packages/release/bioc/vignettes/SC3/inst/doc/SC3.html
##############################
library(SC3)
library(SingleCellExperiment)
# create a SingleCellExperiment object
sce <- SingleCellExperiment(
    assays = list(
        counts = as.matrix(Seg_counts),
        logcounts = log2(as.matrix(Seg_counts) + 1)
    ), 
    colData = data.frame(cell_name = colnames(Seg_counts),
                         true_label = Seg_true_cell_label)
)

# define feature names in feature_symbol column
rowData(sce)$feature_symbol <- rownames(sce)
# remove features with duplicated names
sce <- sce[!duplicated(rowData(sce)$feature_symbol), ]

sce = sc3_prepare(sce)
## if you don't know true number of clusters
sce = sc3_estimate_k(sce)
K = sce@metadata$sc3$k_estimation
K

# cluster with sc3; k is the number of clusters
# this takes ~2.1min
sce <- sc3(sce, ks = 5:6, biology = TRUE, n_cores = 4)
# save(sce, file = "sc3_output_Seg.RData")
# load("sc3_output_Seg.RData")

# explore results interactively
# sc3_interactive(sce)

# very accurate clustering results
col_data <- colData(sce)
head(col_data[ , grep("sc3_", colnames(col_data))])
table(col_data$sc3_5_clusters, col_data$true_label)
table(col_data$sc3_6_clusters, col_data$true_label)

# plot consensus matrix
# similarity between the cells based on the averaging of clustering results from 
# all combinations of clustering parameters
# give this step ~1min to print out the plot
sc3_plot_consensus(
    sce, k = 6, 
    show_pdata = c(
        "true_label", 
        "sc3_6_clusters", 
        "sc3_6_log2_outlier_score"
    )
)

# draw heatmap of expression data
sc3_plot_expression(sce, k = 6,
                    show_pdata = c(
                        "true_label", 
                        "sc3_6_clusters", 
                        "sc3_6_log2_outlier_score"
                    ))

# plot DE genes
# zoom out the plot to see it more clear
sc3_plot_de_genes(
    sce, k = 6, 
    show_pdata = c(
        "true_label", 
        "sc3_6_clusters", 
        "sc3_6_log2_outlier_score"
    )
)

# plot marker genes
sc3_plot_markers(sce, k = 6)

##############################
## monocle
## Tailored from https://cole-trapnell-lab.github.io/monocle3/docs/trajectories/
##############################

load("Embryo_data.RData")
dim(embryo_expr) # data has been truncated to make it small
head(embryo_cell_meta, 3)
head(embryo_gene_ann)

library(monocle3)
cds <- new_cell_data_set(embryo_expr,
                         cell_metadata = embryo_cell_meta,
                         gene_metadata = embryo_gene_ann)
cds <- preprocess_cds(cds, num_dim = 50)
# batch correction using MNN
cds <- align_cds(cds, alignment_group = "batch")

cds <- reduce_dimension(cds)
plot_cells(cds, label_groups_by_cluster=FALSE,  color_cells_by = "cell.type")

ciliated_genes <- c("che-1",
                    "hlh-17",
                    "nhr-6",
                    "dmd-6",
                    "ceh-36",
                    "ham-1")

plot_cells(cds,
           genes=ciliated_genes,
           label_cell_groups=FALSE,
           show_trajectory_graph=FALSE)

cds <- cluster_cells(cds, reduction_method = "UMAP")
plot_cells(cds, color_cells_by = "partition")

# calculate pseudotime and build graph
# takes ~ 10 seconds
cds <- learn_graph(cds)


plot_cells(cds,
           color_cells_by = "cell.type",
           label_groups_by_cluster=FALSE,
           label_leaves=TRUE,
           label_branch_points=FALSE)

plot_cells(cds,
           color_cells_by = "embryo.time.bin",
           label_cell_groups=FALSE,
           label_leaves=TRUE,
           label_branch_points=TRUE,
           graph_label_size=1.5)

# manually select start point for trajectory
cds <- order_cells(cds)

plot_cells(cds,
           color_cells_by = "pseudotime",
           label_cell_groups=FALSE,
           label_leaves=FALSE,
           label_branch_points=FALSE,
           graph_label_size=1.5)

