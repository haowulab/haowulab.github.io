## Compare with other simulators splatt and scDesign ##
library(scDesign)
library(splatter)
library(POWSC)
library(ggpubr)
library(matrixStats)

sixStats = function(mat){
    require(SingleCellExperiment)
    if (is(mat, "SingleCellExperiment")){
        Y = round(assays(mat)[[1]])
    }else{
        Y = round(mat)
    }
    # Y = log10(Y + 1)
    M = rowMeans(Y)
    V = rowVars(Y)
    CV = sqrt(V) / M
    ZeroR = rowSums(Y == 0)/ ncol(Y)
    ZeroC = colSums(Y == 0)/ nrow(Y)
    LibS = colSums(Y)/ 1e6
    return(list(M = M, V = V, CV = CV, ZeroR = ZeroR, ZeroC = ZeroC, LibS = LibS))
}


simulator_compare = function(mat){
    ncell = ncol(mat)
    scDesign_sim = design_data(realcount = mat, S = 1e7, ncell = ncell,
                               ngroup = 1, pUp = 0.05, pDown = 0.05)
    est_paras = Est2Phase(sce = mat)
    POWSC_sim = Simulate2SCE(n = ncell*2, estParas1 = est_paras, estParas2 = est_paras)
    POWSC_sim = assays(POWSC_sim$sce)$counts[, 1:ncell]
    splat_paras = splatEstimate(mat)
    splat_sim = splatSimulate(splat_paras, method = "single")
    splat_sim = assays(splat_sim)$counts
    # six statistics
    real_stats = sixStats(mat)
    scDesign_stats = sixStats(scDesign_sim)
    POWSC_stats = sixStats(POWSC_sim)
    splat_stats = sixStats(splat_sim)
    sum_all = list(scDesign = scDesign_stats, POWSC= POWSC_stats, splat = splat_stats, real_stats = real_stats)
    return(sum_all)
}

computeMAD = function(vec1, vec2) {
    ## deal with NA values. I will ignore them
    ix = is.na(vec1) | is.na(vec2)
    vec1[ix] = 0
    vec2[ix] = 0
    median(abs(sort(vec1)-sort(vec2)))
}


draw_hist = function(sum_all, method = c("MAD", "KS")){
    method = match.arg(method)
    tmp_rslt = NULL
    real_stats = sum_all[[4]]
    if (method == "MAD"){
        for (j in 1:3){
            tmp_sum = sum_all[[j]]
            tmp_D = as.vector(sapply(1:6, function(i){
                computeMAD(tmp_sum[[i]], real_stats[[i]])
            }))
            tmp_rslt = rbind(tmp_rslt, as.vector(tmp_D))
        }
        tmp_rslt = apply(tmp_rslt, 2, function(x) x/max(x))
    }else{
        for (j in 1:3){
            tmp_sum = sum_all[[j]]
            tmp_D = as.vector(sapply(1:6, function(i){
                vec1 = as.vector(tmp_sum[[i]])
                vec2 = as.vector(real_stats[[i]])
                tmp_test = ks.test(vec1, vec2)
                return(tmp_test$statistic)
            }))
            tmp_rslt = rbind(tmp_rslt, as.vector(tmp_D))
        }
    }
    six_stats = c("Mean", "Variance", "CV", "Gene 0 Ratio", "Cell 0 Ratio", "Library Size")
    simulators = names(sum_all)[1:3]
    dimnames(tmp_rslt) = list(simulators, six_stats)
    mat = tmp_rslt
    sumdata = data.frame(values = as.vector(mat),
                         variables = rep(colnames(mat), each = 3),
                         simulator = rep(rownames(mat), 6))
    breaks = round(seq(0, max(mat), length = 11), 1); max_v = max(mat)
    sumdata$variables = factor(sumdata$variables, levels = unique(sumdata$variables))
    p = ggplot(data=sumdata, aes(x=variables, y=values, fill=simulator)) +
        geom_bar(width=0.6, position=position_dodge(width=0.65), stat="identity") +
        xlab("summary statistics") + ylab(method) +
        theme_classic() +
        scale_y_continuous(breaks=breaks, limits = c(0, max_v+0.1), labels=breaks)+
        theme(legend.position = c(0.5, 0.9), legend.direction = "horizontal") +
        theme(plot.title = element_text(size=16, face="bold"))+
        theme(plot.title = element_text(size=16, face="bold"),
              axis.text=element_text(size=12),
              axis.title.x = element_text(size=12, face="bold"),
              axis.title.y = element_text(size=12, face="bold"))+
        ggtitle("Simulator Comparison")
    return(list(p =p, sumdata = sumdata))
}













