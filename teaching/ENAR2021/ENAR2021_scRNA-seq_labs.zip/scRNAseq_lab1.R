###################################################
##
## ENAR 2021 scRNA-seq short course lab 1.
##
## Data exploration, SingleCellExperiment, scater, tSNE, UMAP
##
## Prepared by Hao Wu
##
###################################################

###################################
## pacakge installation
###################################
BiocManager::install("SingleCellExperiment")
install.packages("Rtsne")
install.packages("umap")

###################################
## load in and briefly explore data
###################################
load("Seg_PancreasData.RData")
ls()
dim(Seg_counts)
Seg_counts[1:5,1:5]

table(Seg_subject_ID)
table(Seg_true_cell_label)
table(Seg_subject_ID, Seg_true_cell_label)


##############################
## use SingleCellExperiment
##############################
library(SingleCellExperiment)
sce = SingleCellExperiment(Seg_counts)
sce

sce <- SingleCellExperiment(list(counts=Seg_counts),
                            colData=DataFrame(subject=as.factor(Seg_subject_ID),
                                              celltype=as.factor(Seg_true_cell_label))
                            )
sce
colData(sce)
str(counts(sce))

##############################
## scater
##############################
library(scater)
sce <- logNormCounts(sce) ## add log normalized counts
sce

plotExpression(sce, rownames(sce)[1:4])
plotExpression(sce, rownames(sce)[1:4], x = "celltype")

vars <- getVarianceExplained(sce, variables=c("subject", "celltype"))
head(vars)
plotExplanatoryVariables(vars)

sce <- runTSNE(sce, perplexity=10)
plotTSNE(sce, colour_by = "celltype")
plotTSNE(sce, colour_by = "subject")

sce <- runUMAP(sce)
plotUMAP(sce, colour_by = "celltype")
plotUMAP(sce, colour_by = "subject")

##############################
## tSNE
##############################
library(Rtsne)
library(colorspace)

# res = Rtsne(t(Seg_counts))
## it's better to use log normalized data
x=logcounts(sce)
res = Rtsne(t(x))

par(mfrow=c(1,2), mar = c(2.5, 2.5, 1.6, 0.5), mgp = c(1.4, 0.5, 0))
mycolor = rainbow_hcl(3)
plot(res$Y[,1:2], pch = 19, cex=0.6,  col=mycolor[Seg_subject_ID],
     xlab="tSNE1", ylab="tSNE2")
legend("topright", col = mycolor, legend = paste0("sample", 1:3),
       pch = 19,  bty = "n")

mycolor = rainbow_hcl(6)
CTidx = as.integer(as.factor(Seg_true_cell_label))
plot(res$Y[,1:2], pch = 19, cex=0.6,  col=mycolor[CTidx],
          xlab="tSNE1", ylab="tSNE2")
legend("topright", col = mycolor, legend=levels(as.factor(Seg_true_cell_label)),
       pch = 19,  bty = "n")


##############################
## UMAP
##############################
library(umap)

set.seed(1234)
x=logcounts(sce)
res <- umap(t(x))

par(mfrow=c(1,2),mar = c(2.5, 2.5, 1.6, 0.5), mgp = c(1.4, 0.5, 0))
mycolor = rainbow_hcl(3)
plot(res$layout[,1:2], pch = 19, cex=0.6,  col=mycolor[Seg_subject_ID],
     xlab="UMAP1", ylab="UMAP2")
legend("bottomleft", col = mycolor, legend = paste0("sample", 1:3),
       pch = 19,  bty = "n")

mycolor = rainbow_hcl(6)
CTidx = as.integer(as.factor(Seg_true_cell_label))
plot(res$layout[,1:2], pch = 19, cex=0.6,  col=mycolor[CTidx],
     xlab="UMAP1", ylab="UMAP2")
legend("bottomleft", col = mycolor, legend=levels(as.factor(Seg_true_cell_label)),
       pch = 19,  bty = "n")




