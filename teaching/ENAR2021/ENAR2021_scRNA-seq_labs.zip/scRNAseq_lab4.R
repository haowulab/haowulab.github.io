###################################################
##
## ENAR 2021 scRNA-seq short course lab 4.
##
## Supervised cell annotation: singleR, scmap, CHETAH
##
## Prepared by Ziyi Li
##
###################################################

###################################
## pacakge installation
###################################
BiocManager::install("scmap")
BiocManager::install("CHETAH")
BiocManager::install("SingleR")
BiocManager::install("celldex")

###################################
## Use Seg Pancreas data as the target data for annotation
###################################
load("Seg_PancreasData.RData")

library(SingleCellExperiment)
sce <- SingleCellExperiment(list(counts=Seg_counts),
                            colData=DataFrame(subject=as.factor(Seg_subject_ID)))
library(scater)
sce <- logNormCounts(sce) ## add log normalized counts

##############################
## SingleR
## A very popular cell annotation package on bioconductor
## tailored based on https://bioconductor.org/packages/release/bioc/vignettes/SingleR/inst/doc/SingleR.html
##############################
## try annotation cells using the HPCA data
library(SingleR)
library(celldex)
hpca.se <- HumanPrimaryCellAtlasData()

pred.hesc <- SingleR(test = sce, ref = hpca.se, assay.type.test=1,
                     labels = hpca.se$label.main)
table(pred.hesc$labels, Seg_true_cell_label)
## we already know these cells are all pancreas cells
## this annotation is not very accurate

## use another pancreas dataset as reference
load("Baron_PancreasData.RData")
sceB <- SingleCellExperiment(list(counts=Baron_counts),
                            colData=DataFrame(subject=as.factor(Baron_subject_ID),
                                              celltype=as.factor(Baron_true_cell_label)))
sceB <- logNormCounts(sceB) ## add log normalized counts

pred_useB <- SingleR(test=sce, ref=sceB, labels=sceB$celltype, de.method="wilcox")
table(pred_useB$labels, Seg_true_cell_label)

## do additional plots for decition score and expression heatmap
plotScoreHeatmap(pred_useB)
all.markers <- metadata(pred_useB)$de.genes
sce$labels <- pred_useB$labels
plotHeatmap(sce, order_columns_by="labels",
            features=unique(unlist(all.markers$beta))) 

##############################
## scmap
## tailored based on https://bioconductor.org/packages/release/bioc/vignettes/scmap/inst/doc/scmap.html
##############################
library(scmap)

library(SingleCellExperiment)
sce <- SingleCellExperiment(list(counts=Seg_counts),
                            colData=DataFrame(subject=as.factor(Seg_subject_ID)))
library(scater)
sce <- logNormCounts(sce) ## add log normalized counts


# use gene names as feature symbols
rowData(sceB)$feature_symbol <- rownames(sceB)
rowData(sce)$feature_symbol <- rownames(sce)
# remove features with duplicated names
sceB <- sceB[!duplicated(rownames(sceB)), ]
sce <- sce[!duplicated(rownames(sce)), ]

## first do some feature selection
sceB <- selectFeatures(sceB, suppress_plot = FALSE)

################## use scmap-cluster to annotate Seg data
sceB <- indexCluster(sceB, cluster_col = "celltype")
head(metadata(sceB)$scmap_cluster_index)
heatmap(as.matrix(metadata(sceB)$scmap_cluster_index))

scmapCluster_results <- scmapCluster(
    projection = sce, 
    index_list = list(
        Baron = metadata(sceB)$scmap_cluster_index
    )
)
## check accuracy
table(scmapCluster_results$scmap_cluster_labs, Seg_true_cell_label)

## visualization
plot(
    getSankey(
        Seg_true_cell_label, 
        scmapCluster_results$scmap_cluster_labs[,'Baron'],
        plot_height = 400
    )
)

################## use scmap-cell to annotate Seg dat
sceB <- indexCell(sceB)
scmapCell_results <- scmapCell(
    sce, 
    list(
        Baron = metadata(sceB)$scmap_cell_index
    )
)
scmapCell_clusters <- scmapCell2Cluster(
    scmapCell_results, 
    list(
        as.character(colData(sceB)$celltype)
    )
)
table(scmapCell_clusters$scmap_cluster_labs, Seg_true_cell_label)

##############################
## CHETAH
## tailored based on http://www.bioconductor.org/packages/release/bioc/vignettes/CHETAH/inst/doc/CHETAH_introduction.html
##############################
library(CHETAH)
sce <- CHETAHclassifier(input = sce, ref_cells = sceB,
                        ref_ct = "celltype")

## add tsne results for Seg data
library(Rtsne)
x=logcounts(sce)
res = Rtsne(t(x))
tsne_Seg <- res$Y
rownames(tsne_Seg) <- colnames(sce)
colnames(tsne_Seg) <- c("tSNE_1", "tSNE_2")
reducedDims(sce) <- SimpleList(tsne_Seg)

PlotCHETAH(sce)

celltypes <- sce$celltype_CHETAH
table(celltypes, Seg_true_cell_label)


