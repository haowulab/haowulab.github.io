###################################################
##
## ENAR 2021 scRNA-seq short course lab 2.
##
## Normalization, batch effect correction, imputation, 
## DE, data simulator
##
## Prepared by Hao Wu
##
###################################################

###################################
## pacakge installation
###################################
library(devtools)
BiocManager::install("SCnorm")
BiocManager::install("scran")
BiocManager::install("batchelor")
install.packages("SAVER")
install.packages("DrImpute")
BiocManager::install("MAST")
BiocManager::install("splatter")
Sys.setenv(R_REMOTES_NO_ERRORS_FROM_WARNINGS=TRUE)
install_github("Vivianstats/scDesign")
install_github("haowulab/SC2P", build_vignettes=TRUE) # POWSC requires SC2P to be installed first
install_github("suke18/POWSC", build_vignettes = T, dependencies = T)

###################################
## load in data
###################################
library(SingleCellExperiment)
load("Seg_PancreasData.RData")
sce <- SingleCellExperiment(list(counts=Seg_counts),
                            colData=DataFrame(subject=as.factor(Seg_subject_ID),
                                              celltype=as.factor(Seg_true_cell_label)))
library(scater)
sce <- logNormCounts(sce) ## add log normalized counts


##############################
## normalization
##############################
X = Seg_counts

## use scran
library(scran)
k <- calculateSumFactors(X) ## this is the size factor
## compare to the total counts
cor(k, colSums(X))
plot(k, colSums(X))
## normalize data
Xnorm = sweep(X, 2, k, FUN="/")

## use SCnorm - this is slow. Skip if it takes too long
library(SCnorm)
library(parallel)
ncores = detectCores()-3
design = rep(1, ncol(X))
DataNorm <- SCnorm(Data = X,
                   Conditions = design,
                   PrintProgressPlots = FALSE,
                   FilterCellNum = 10,
                   NCores=ncores)
Xnorm <- normcounts(DataNorm)

## Take a look at tSNE. Normalization doesn't remove batch effects
library(colorspace)
library(Rtsne)
res = Rtsne(t(log(Xnorm+0.5)))
par(mar = c(2.5, 2.5, 1.6, 0.5), mgp = c(1.4, 0.5, 0), mfrow=c(1,2))
mycolor = rainbow_hcl(3)
plot(res$Y[,1:2], pch = 19, cex=0.6,  col=mycolor[Seg_subject_ID],
     xlab="tSNE1", ylab="tSNE2")
legend("topright", col = mycolor, legend = paste0("sample", 1:3),
       pch = 19,  bty = "n")

mycolor = rainbow_hcl(6)
CTidx = as.integer(as.factor(Seg_true_cell_label))
plot(res$Y[,1:2], pch = 19, cex=0.6,  col=mycolor[CTidx],
     xlab="tSNE1", ylab="tSNE2")
legend("topright", col = mycolor, legend=levels(as.factor(Seg_true_cell_label)),
       pch = 19,  bty = "n")


##############################
## batch effect correction
##############################
library(batchelor)
## run MNN
f.out = fastMNN(sce, batch=Seg_subject_ID)
f.out
colData(f.out) = DataFrame(subject=as.factor(Seg_subject_ID),
                           celltype=as.factor(Seg_true_cell_label))

## take a look at tSNE after MNN
f.out <- runTSNE(f.out, dimred="corrected")
plotTSNE(f.out, colour_by="subject")
plotTSNE(f.out, colour_by="celltype")

## How to take out batch corrected data.
## Note the normalized data are  in log scale
x = as.matrix(assays(f.out)$reconstructed)
range(x)

## Note, even though MNN removes batch effects on tSNE plot,
## it doesn't necessarily improve clustering.
## We will show more of this in later lab.

##############################
## imputation
##############################

##### SAVER
library(SAVER)
library(parallel)
library(foreach)

## SAVER is a little slow. We will use parallel computing. 
ncl = max(detectCores() - 3, 1)
cl = makeCluster(ncl)
doParallel::registerDoParallel(cl)
counts.saver = saver(Seg_counts)
stopCluster(cl)

## take a look at the data after imputation
X.saver = counts.saver$estimate
mean(X.saver == 0)
mean(Seg_counts == 0)

plot(log(Seg_counts[,1]+1), log(X.saver[,1]+1), xlab="Original", ylab="After SAVER")
abline(0,1, lwd=2, col=2)

##### DrImpute
library(DrImpute)
## count data need to be normalized and log transformed before imputation
## We will use the log-normalized data from scater
X0 = counts(sce)
logX0 = logcounts(sce)
X.DrImpute <- DrImpute(logX0)

## take a look at the data after imputation
plot(logX0[,1], X.DrImpute[,1], xlab="Original", ylab="After DrImpute")
abline(0,1, lwd=2, col=2)

## if one wishes to recover the imputed count data
X2 = exp(X.DrImpute)-1
k = colSums(X0) / colSums(X2)
X2 = sweep(X2, 2, k, FUN="*")
## look at correlation of imputed and original data
diag(cor(X0[,1:4], X2[,1:4]))


###################################
## Differential expression
###################################

#### Use MAST for DE
library(MAST)

## Take out data for subject 1, alpha and gamma cells
ix = Seg_subject_ID == 1
ltpm = logcounts(sce)[,ix]
ix.celltype = Seg_true_cell_label[ix]=="alpha" | Seg_true_cell_label[ix]=="gamma"

Y = ltpm[,ix.celltype]
celltype = Seg_true_cell_label[ix][ix.celltype]
sca <- FromMatrix(Y, cData=data.frame(celltype=as.factor(celltype)))

cdr2 <- colSums(assay(sca)>0)
colData(sca)$cngeneson <- scale(cdr2)
thres <- thresholdSCRNACountMatrix(assay(sca),
			nbins=200, min_per_bin=30)
assays(sca) <- list(thresh=thres$counts_threshold,
					tpm=assay(sca))

## fit model and perform test
fit <- zlm(~celltype, sca)
fit

lrt <- lrTest(fit, "celltype")
head(lrt[,,'Pr(>Chisq)'])

## visualize the top DE genes
ix = sort(lrt[,,'Pr(>Chisq)'][,3], index=TRUE)$ix
flat_dat <- as(sca[ix[1:6],], 'data.table')
ggbase <- ggplot(flat_dat, aes(x=celltype, y=thresh,color=celltype)) + geom_jitter()+
    facet_wrap(~primerid, scale='free_y')+ggtitle("DE Genes")
ggbase+geom_violin()


#########################
## simulators
#########################
library(scDesign)
library(splatter)
library(POWSC)
library(ggpubr)
library(matrixStats)

## Simulate data based on the alpha cells in subject 1
ix = Seg_subject_ID == 1
Y0 = Seg_counts[,ix]
ix.celltype = Seg_true_cell_label[ix]=="alpha"
mat = Y0[,ix.celltype]
ncell = ncol(mat)

## simulate using scDesign
scDesign_sim = design_data(realcount = mat, S = 1e7, ncell = ncell, ngroup = 1, pUp = 0.05, pDown = 0.05)

## using POWSC
est_paras = Est2Phase(sce = mat)
POWSC_sim = Simulate2SCE(n = ncell*2, estParas1 = est_paras, estParas2 = est_paras)
POWSC_sim = assays(POWSC_sim$sce)$counts[, 1:ncell]

## using splat
splat_paras = splatEstimate(mat)
splat_sim = splatSimulate(splat_paras, method = "single")
splat_sim = assays(splat_sim)$counts

## compare the metrics from different simulators
source("simulator_comparisons.R")
## comppute six statistics for comparison
real_stats = sixStats(mat)
scDesign_stats = sixStats(scDesign_sim)
POWSC_stats = sixStats(POWSC_sim)
splat_stats = sixStats(splat_sim)
sum_all = list(scDesign = scDesign_stats, POWSC= POWSC_stats, splat = splat_stats, real_stats = real_stats)
draw_hist(sum_all, "MAD")
draw_hist(sum_all, "KS")
