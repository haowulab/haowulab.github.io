###########################################
## some utility functions
###########################################

#### function to estimate NB parameters
est.NB <- function(x) {
  x=x[x<quantile(x, 0.99)] 
  mm=mean(x); vv=var(x)
  phi=(vv-mm)/mm^2
  ## convert to size/prob parametrization for R
  size=1/phi;
  tmp=mm/size
  prob=1/(1+tmp)
  c(size,prob)
}


#### log polya density
lpolya <- function(x, alpha) {
  A0=sum(alpha)
  N=sum(x)
  lgamma(A0)-lgamma(N+A0) + sum(lgamma(x+alpha)-lgamma(alpha))
}

## add two numbers in log domain. This works for vectors too.
Raddlog <- function(a, b) {
  result <- rep(0, length(a))
  idx1 <- a>b+200
  result[idx1] <- a[idx1]

  idx2 <- b>a+200
  result[idx2] <- b[idx2]

  idx0 <- !(idx1|idx2)
  result[idx0] <- a[idx0] + log1p(exp(b[idx0]-a[idx0]))
  result
}

## sum of a vector in log domain
Rsumlog <- function(a) {
  s <- a[1]
  for(i in 2:length(a))
    s <- Raddlog(s, a[i])
  s
}


