#################################################
## rerank peaks given peak list and BAM files
#################################################
rerank.peak <- function(peaks, bamFiles, groups, winsize=50, candLen=800, max.K=6) {
  ## sort peaks according to the score, if available
  if(!is.null(peaks$score)) {
    ix=sort(peaks$score, dec=T, index=T)$ix
    peaks=peaks[ix,]
  }
  ## get data
  tmpdat <- getData.bam(peaks, bamFiles, groups, winsize, candLen)
  
  ## estimate shapes
  K=max.K
  ntopPeaks <- min(1000, ncol(tmpdat$dat.peak))
  cat("Estimating peak shapes: ")
  BIC=rep(0, K)
  shapes=NULL
  dat.topPeaks=tmpdat$dat.peak[,1:ntopPeaks]
  for(i in 1:K) {
    cat(i, ",")
    ## mixture of polya
    shapes[[i]]=.Call("Kpolya", as.double(dat.topPeaks), as.integer(ncol(dat.topPeaks)),
            as.integer(nrow(dat.topPeaks)),as.integer(i))
    BIC[i]=shapes[[i]][[1]]
  }
  shape1=shapes[[which.min(BIC)]]
  names(shape1)=c("BIC", "prop", "pi")
  shape1$prop=matrix(shape1$prop, ncol=which.min(BIC))
  ## estimate background shapes. 
  dat.bg=tmpdat$dat.bg
  tmp=.Call("Kpolya", as.double(dat.bg), as.integer(ncol(dat.bg)), as.integer(nrow(dat.bg)),as.integer(1))
  shape0=tmp[[2]]
    
  ## estimate distributions for total counts
  NB.param=est.NB(colSums(dat.bg))
  a=0; b=sum(tmpdat$dat.peak[,1])

  ## rerank all peaks
  nallpeaks <- ncol(tmpdat$dat.peak)
  lrs=rep(0, nallpeaks)
  for(i in 1:nallpeaks) {
    lrs[i]=computeLR.peak.polya(tmpdat$dat.peak[,i],shape0, shape1, NB.param, a,b)
  }

  ## output reranked peaks with lr
  ix=sort(lrs, dec=TRUE, index=TRUE)$ix
  newpeaks=data.frame(peaks, lr=lrs)
  newpeaks=newpeaks[ix,]

  ## output shapes
  n0=2
  if(all(c(0,1) %in% groups)) n0=4
  shapes.bg=matrix(shape0, ncol=n0)
  shapes.peak=vector("list", ncol(shape1$prop))
  for(i in 1:ncol(shape1$prop)) {
    shapes.peak[[i]]=matrix(shape1$prop[,i], ncol=n0)
  }

  ## return
  list(peaks=newpeaks, shapes.peak=shapes.peak, shapes.bg=shapes.bg)
}

################################################
## compute LR for peaks based on polya model
################################################
computeLR.peak.polya <- function(dat, shape0, shape1, NB.param, a,b) {
  eps0=log(0.001)
  eps1=log(1-0.001)
  nbins=nrow(dat)
  totC=sum(dat)
  
  ## Pr(\sum X|Z=1) - Pr(\sum X|Z=0)
  p0.totC=dnbinom(totC, NB.param[1], NB.param[2], log=TRUE)
  p1.totC=log(b-a)
  p0.totC=Raddlog(p0.totC+eps1, p1.totC+eps0)
  p1.totC=Raddlog(p1.totC+eps0, p1.totC+eps1)
  lr.totC=p1.totC-p0.totC

  ## Pr(X|\sum X, Z=1) - Pr(X|\sum X, Z=0)
  nshapes=ncol(shape1$prop)
  lpi=log(shape1$pi)
  lshape0=log(shape0)
  lr.X=-Inf
  postprob=tt=rep(0, nshapes)
  p.diff=rep(0,nshapes)
  for(i in 1:nshapes) {
    p.diff[i]=lpolya(dat, shape1$prop[,i]) - lpolya(dat, shape0)
  }
  lr.X=Rsumlog(p.diff+lpi)
  lr=lr.totC + lr.X
  lr
}
