.First.lib <- function(lib, pkg) library.dynam("makeCGI", pkg, lib)

