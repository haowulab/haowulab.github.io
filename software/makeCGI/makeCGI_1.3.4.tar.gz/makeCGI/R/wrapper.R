#######################################################################
## wrapper function
## Take some options and a data frame for repeats then generate CGI table
#######################################################################
makeCGI <- function(.CGIoptions) {
  if(missing(.CGIoptions))
    .CGIoptions <- CGIoptions()
  cat("counting C/G/CG ...\n")
  count.CG(.CGIoptions)
  ff=dir(.CGIoptions$CountsDir, pattern="Count")
  ## clean up data - removes regions with Ns and repeats
  cleanup(ff, .CGIoptions)
  ## iterative HMM for G+C
  cat("iterative HMM for G+C ... \n")
  HMM.GC(.CGIoptions)
  ## HMM for CpG
  cat("HMM for CpG ... \n")
  HMM.CpG(.CGIoptions)
  ## grab the results and make a table.
  makeResult(.CGIoptions)
  ## annotate CGI tables
  cat("Annotate CGIs ...\n")
  annotateCGI(.CGIoptions)
  ## remove temporary files
#  file.remove(dir(.CGIoptions$tmpDir, pattern="^result.*.rda", full.names=TRUE))
#  file.remove(dir(.CGIoptions$tmpDir, pattern="^ft.*.rda", full.names=TRUE))
}

######################################
## function to make default options
######################################
CGIoptions <- function() {
  ## default options
  .CGIoptions=NULL
  .CGIoptions$rawdat.type="BSgenome"
  .CGIoptions$CountsDir="counts"
  .CGIoptions$tmpDir="tmp"
  .CGIoptions$resultDir="result"
  .CGIoptions$GCHMM.niter=5
  .CGIoptions$EM.TOL=1e-4
  .CGIoptions$EM.niter=100
  .CGIoptions$windowSize=16
  .CGIoptions$SmoothWS=400 ## this is in bp
  .CGIoptions$cutoff.GCcontent=0.5
  .CGIoptions$cutoff.CpG=0.99

  ## check directories, make them if not existing
  if(!file.exists(.CGIoptions$CountsDir)) {
    warning(paste("making directory:", .CGIoptions$CountsDir))
    dir.create(.CGIoptions$CountsDir)
  }
  if(!file.exists(.CGIoptions$tmpDir)) {
    warning(paste("making directory:", .CGIoptions$tmpDir))
    dir.create(.CGIoptions$tmpDir)
  }
  if(!file.exists(.CGIoptions$resultDir)) {
    warning(paste("making directory:", .CGIoptions$resultDir))
    dir.create(.CGIoptions$resultDir)
  }

  .CGIoptions
}

#######################################################################
## this function is to clean up data, remove N bases and repeats
## then save the results as rda
#######################################################################

cleanup <- function(CountFiles, .CGIoptions) {
  n0 <- 0 ## total number of bases in the genome without repeats
  ## read in repeat file
  rptfile <- paste("rawdata/repeats.rda")
  if(!file.exists(rptfile)) { ## no rda, read in txt
    fn <- "rawdata/repeats.txt"
    if(!file.exists(fn)) { ## no text repeat file, set repeats to NULL
      repeats <- NULL
    } else { ## read in txt - I assume it's from UCSC
      cat("Reading in repeats ...\n")
      tmp <- read.table(fn, sep="\t", header=TRUE, comment.char="")
      ## keep only the alus
      idx <- tmp$repName=="Alu"
      repeats <- tmp[idx, c("genoName", "genoStart", "genoEnd")]
      colnames(repeats) <- c("chr","start","end")
      rownames(repeats) <- NULL
      save(repeats, file=rptfile)
    }
  } else {
    load(rptfile)
  }

  L <- .CGIoptions$windowSize
  for(i in 1:length(CountFiles)) {
      chr <- gsub(".rda", "", gsub("Counts.", "", CountFiles[i]))
      ## chr <- strsplit(CountFiles[i], "\\.")[[1]][2]
    cleandata <- paste(.CGIoptions$tmpDir, "/cleandata.",chr,".rda",sep="")
    if(!file.exists(cleandata)) {
      load(paste(.CGIoptions$CountsDir,CountFiles[i],sep="/"))
      dat <- get(ls(pattern="Counts"))
      rm(list=ls(pattern="Counts"))
      ## get repeats for this chromosome
      if(!is.null(repeats)) {
        repeats.chr <- repeats[repeats$chr==chr,c("start", "end"),drop=FALSE]
      }    else
      repeats.chr <- NULL
      ## remove alu and N
      res0 <- data.takerpt(dat, repeats.chr, N=L)
      save(res0, file=cleandata)
      n0 <- n0 + nrow(res0$dat)
    }
  }
  n0 <- n0*L
  save(n0, file=paste(.CGIoptions$resultDir,"totalBases.rda",sep="/"))
}


############################################################
## function to run iterative HMM for G+C content
## inputs are files for counts (one for each chr) and repeats
############################################################
HMM.GC <- function(.CGIoptions) {
  CleanFiles <- dir(.CGIoptions$tmpDir, pattern="cleandata")
  nchr <- length(CleanFiles)
  dd <- 1
  mus.old <- c(0,0)
  iter <- 1
  while((dd>1e-2) & iter<=.CGIoptions$GCHMM.niter) {
    cat("\nGC content iterative HMM, iter ", iter, ": ",sep="")
    if(iter==1) { ## first iteration, run it
      for(ichr in 1:nchr) {
          chr <- gsub(".rda", "", gsub("cleandata.", "", CleanFiles[ichr]))
          ## chr <- strsplit(CleanFiles[ichr], "\\.")[[1]][2]
          cat(chr, ",")
          ## run HMM for each chr, this can be distributed to multiple computers
          HMM.GC.chr(CleanFiles[ichr], .CGIoptions)
      }
      ## estimate parameters
      param <- getAllParam.GCcontent(.CGIoptions)
      if(nchr>1) {
        ## final run of HMM
        cat("\nRerun HMM for all chromosomes ...\n")
        for(ichr in 1:nchr)
          HMM.GC.chr(CleanFiles[ichr], .CGIoptions, param=param)
      }
    }
    else { ## later iteration, use Ngc=Ngc0-ft
      for(ichr in 1:nchr) {
          chr <- gsub(".rda", "", gsub("cleandata.", "", CleanFiles[ichr]))
          ## chr <- strsplit(CleanFiles[ichr], "\\.")[[1]][2]
        cat(chr, ",")
        if(exists("Ngc"))     rm(pattern="Ngc")
        load(paste(.CGIoptions$tmpDir, "/ft.GCcontent.",chr, ".rda", sep=""))
        HMM.GC.chr(CleanFiles[ichr], .CGIoptions, Ngc=Ngc)
      }
      ## estimate parameters
      param <- getAllParam.GCcontent(.CGIoptions)
      if(nchr>1) {
        ## final run of HMM
        for(ichr in 1:nchr) {
          chr <- gsub(".rda", "", gsub("cleandata.", "", CleanFiles[ichr]))
          cat(chr, ",")
          if(exists("Ngc"))     rm(pattern="Ngc")
          load(paste(.CGIoptions$tmpDir, "/ft.GCcontent.",chr, ".rda", sep=""))
          cat("\nRerun HMM for all chromosomes ...\n")
          HMM.GC.chr(CleanFiles[ichr], .CGIoptions, param=param, Ngc=Ngc)
        }
      }
    }
    ## smoothing
    cat("Smoothing ...\n")
    calcFt(.CGIoptions)
    ## computing of Ngc-f(t) will be done in HMM.GC.chr
    ## check convergence
    mus <- c(param$mu0,param$mu1)
    dd <- sqrt(sum(mus-mus.old)^2)
    mus.old <- mus
    cat("dd=",dd,"\n")
    iter <- iter + 1
  }
}

############################################################
## function to run  HMM for CpG counts, given ft and G+C counts
## inputs are files for counts (one for each chr) and repeats
############################################################
HMM.CpG <- function(.CGIoptions) {
  CleanFiles <- dir(.CGIoptions$tmpDir, pattern="cleandata")
  nchr <- length(CleanFiles)

  cat("CpG HMM: ")
  ## run for each chromosome
  for(ichr in 1:nchr) {
      chr <- gsub(".rda", "", gsub("cleandata.", "", CleanFiles[ichr]))
      ## chr <- strsplit(CleanFiles[ichr], "\\.")[[1]][2]
    cat(chr, ",")
    ## run HMM for each chr, this can be distributed to multiple computers
    HMM.CpG.chr(CleanFiles[ichr], .CGIoptions)
  }
  ## estimate parameters
  param <- getAllParam.CpG(.CGIoptions)
  if(nchr>1) {
    ## final run of HMM
    cat("Rerun HMM for all chromosomes ...\n")
    for(ichr in 1:nchr)
      HMM.CpG.chr(CleanFiles[ichr], .CGIoptions, param=param)
  }
}


###############################################
## calculate smoothing ft
## ft=Ngc-mu1*Xt
###############################################
calcFt <- function(opts) {
  ## necessary files
  CleanFiles <- dir(opts$tmpDir, pattern="cleandata")
  resultFiles <- dir(opts$tmpDir, pattern="result.GCcontent")
  ws=round(.CGIoptions$SmoothWS/.CGIoptions$windowSize)

  FN <- floor((ws-1)/2)
  Tukey = function(x) pmax(1 - x^2,0)^2
  fs= Tukey(seq(-FN,FN)/(FN+1));fs=fs/sum(fs)

  nchr <- length(resultFiles)
  for(ichr in 1:nchr) {
      chr <- gsub(".rda", "", gsub("cleandata.", "", CleanFiles[ichr]))
      ## chr <- strsplit(CleanFiles[ichr], "\\.")[[1]][2]
    load(paste(.CGIoptions$tmpDir,CleanFiles[ichr],sep="/"))
    load(paste(.CGIoptions$tmpDir,resultFiles[ichr],sep="/"))
    nn <- nrow(res0$dat); ll <-res0$ll
    Ngc0 <- rowSums(res0$dat[,c("C","G")])

    ## smoothing
    Xt=result$postprob>0.5
    resid=Ngc0-result$mu0-(result$mu1-result$mu0)*Xt ## residual
    ## ft
    ft=mySmooth(resid, ll, fs)
    ## adjusted
    Ngc=Ngc0 - ft
    resultfile <- paste(.CGIoptions$tmpDir, "/ft.GCcontent.",chr, ".rda", sep="")
    save(Ngc, file=resultfile)
  }
}

##########################################################
## a function to make a data frame for the results.
## data frame contains 4 columns: chr, pos, pp.GC, pp.CpG
## only places with both PP>0.5 will be saved
##########################################################
makeResult <- function(opts) {
  K <- round(opts$windowSize/8)
  L <- 8*K

  ## result files for G+C and CpG
  files.GC.results <- dir(opts$tmpDir, pattern="result.GCcontent")
  files.CpG.results <- dir(opts$tmpDir, pattern="result.CpG")
  ## clean data
  files.cleandata <- dir(opts$tmpDir, pattern="cleandata")

  nchr <- length(files.cleandata)
  for(ichr in 1:nchr) {
      chr <- gsub(".rda", "", gsub("cleandata.", "", files.cleandata[ichr]))
      ## chr <- strsplit(files.cleandata[ichr], "\\.")[[1]][2]
    fn.GC.results <- paste(opts$tmpDir, "/result.GCcontent.",chr, ".rda", sep="")
    fn.CpG.results <-paste(opts$tmpDir, "/result.CpG.",chr, ".rda", sep="")
    fn.cleandata <- paste(opts$tmpDir, files.cleandata[ichr], sep="/")
    load(fn.cleandata)
    pos <- res0$pos.idx * L
    load(fn.GC.results)
    pp.GCcontent <- result$postprob
    idx <- pp.GCcontent > 0
    load(fn.CpG.results)
    Pcg <- result$Pc
    pp.CpG <- result$postprob
    idx <- idx & pp.CpG > 0.5
    if(sum(idx)==0) ## none on this chr
      next
    result <- data.frame(chr=chr, pos=pos[idx], pp.GCcontent=pp.GCcontent[idx],
                         pp.CpG=pp.CpG[idx], CpG=res0$dat[idx,"CG"],
                         GC=rowSums(res0$dat[idx, c("C","G"),drop=FALSE]), Pcg=Pcg[idx])
    save.file <- paste(opts$resultDir, "/result.", chr, ".rda", sep="")
    save(result, file=save.file)
  }
}

