fuzzy.match = function(x, y, x.sorted = FALSE, y.sorted = FALSE) {

	l.x = length(x)
	# space for results
	r = array(0,c(l.x,2))

	if (! x.sorted) {
		# sort x
		perm = order(x)
		X = x[perm]
	}

	l.y = length(y)
	if (! y.sorted) {
		Y = array(0,1+l.y)
		# sort y
		perm.y = order(y)
		Y[1:l.y] = y[perm.y]
		Y[1+l.y] = +Inf
	}
	else
		y[1+l.y] = +Inf

	# set up
	v = -Inf
	j = 1
	if (y.sorted)
		u = y[j]
	else
		u = Y[j]
	# run over X, or x if x.sorted
	for (i in 1:l.x) {
		if (x.sorted)
			z = x[i]
		else
			z = X[i]
		e = z - v
		d = u - z
		while (d < 0) {
			v = u
			e = z - v
			j = j + 1
			if (y.sorted)
				u = y[j]
			else
				u = Y[j]
			d = u - z
		}
		# result
		if (x.sorted)
			k = i
		else
			k = perm[i]		
		if (y.sorted)
			r[k,2] = j
		else
			r[k,2] = perm.y[j]
		if (d == 0)
			r[k,1] = 0
		else if (e < d) {
			r[k,1] = -e
			if (y.sorted)
				r[k,2] = j-1
			else
				r[k,2] = perm.y[j-1]
		}
		else # e >= d
			r[k,1] = d
	}
	r
}

fuzzy.match2 = function(x, z, x.sorted = FALSE, z.sorted = FALSE) {
	# z is an Nx2 matrix whose rows are separate intervals
	# which play the role of the y-elements in fuzzy.match
	if (z.sorted)
		y = t(z)
	else {
		perm = order(z[,1])
		y = t(z[perm,])
	}
	f = fuzzy.match(x,y,x.sorted=x.sorted,y.sorted=TRUE)
	for (i in 1:length(x)) {
		d = f[i,1]	# distance from as.vector(y)
		j = f[i,2]	# nearest index of as.vector(y)
		jmod2 = j%%2
		if (z.sorted)
			f[i,2] = (j+jmod2)/2
		else
			f[i,2] = perm[(j+jmod2)/2]
		if ((d>0 && jmod2==0) || (d<0 && jmod2 == 1))
			f[i,1] = 0
	}
	f
}

fuzzy.match3 = function(u, v) {
	# u and v are assumed to be sorted-increasing.
	# Returns a vector g of same length as u, such that
	# u[i] lies in the interval [v[g[i]],v[g[i]+1]).  So
	# if u[i] occurs in v, it is equal to v[g[i]], and
	# otherwise, it lies between v[g[i]] and v[g[i]+1].
	g = fuzzy.match(u, v, x.sorted=TRUE, y.sorted=TRUE)
	for (i in 1:length(u))
		if (g[i,1] > 0)
			g[i,2] = g[i,2] - 1
	g[,2]
}
