### given counts calculate posterior probabilities of
## being CGI and save

calc.postprob <- function() {
  ## read in repeats
  if(!is.null(.CGIoptions$repeat.file)) {
    repeats <- read.table(.CGIoptions$repeat.file, header=TRUE,sep="\t")
    colnames(repeats) <- c("chr","start","end")
    save(repeats, paste(.CGIoptions$tmpdir,"/repeats.rda",sep=""))
  }
  else
    repeats=NULL
  ## get the list of counts
  count.files=dir(.CGIoptions$tmpdir, patter="Counts.")
  ## step 1: run forward-backward with EM
  cat("Forward-backward with EM:\n")
  for(ff in count.files) {
    load(paste(.CGIoptions$tmpdir,ff,sep="/"))
    assign("dat", get(ls(pattern="Counts")))
    rm(list=ls(pattern="Counts"))
    chr <- base:::substr(unlist(strsplit(ff,"\\."))[1],8,1000)
    cat("\n########", chr, "########:\n\n")
    ## run EM with HMM
    repeats.chr <- repeats[repeats$chr==chr,]
    result <- findCpG.noalu.engine.all(dat, repeats.chr, CG.equal=TRUE,
                                       N=.CGIoptions$L,K=1,wsize=5)

    ## save
    fname <- paste(.CGIoptions$tmpdir,"/EM.result-", chr, ".rda", sep="")
    save(result, file=fname)
  }

  ## step 2: calculate aggregated parameters (init/trans/emit probabilites)
  ## based on results from all chromosomes
  cat("Calculate parameters ... \n")
  getAllParam()

  ## step 3: run forward-backward with estimated parameters
  load(paste(.CGIoptions$tmpdir,"/allparam.rda",sep=""))
  cat("\n\nFinal forward-back:\n")
  for(ff in count.files) {
    load(paste(.CGIoptions$tmpdir,ff,sep="/"))
    assign("dat", get(ls(pattern="Counts")))
    rm(list=ls(pattern="Counts"))
    chr <- base:::substr(unlist(strsplit(ff,"\\."))[1],8,1000)
    cat("\n########", chr, "########:\n\n")
    ## run EM with HMM
    repeats.chr <- repeats[repeats$chr==chr,]
    result <- findCpG.noalu.engine.all(dat, repeats.chr, CG.equal=TRUE,
                                       N=.CGIoptions$L,K=1,wsize=5,
                                       l0=l0,l1=l1,mu0=mu0,mu1=mu1,std=std,
                                       init.prob.CpG=log(initprob.CpG),
                                       trans.prob.CpG=log(transprob.CpG),
                                       init.prob.GCcontent=log(initprob.GCcontent),
                                       trans.prob.GCcontent=log(transprob.GCcontent),
                                       nmaxiter=1)

    ## grab the section where both posterior probabilites bigger than 0.5
    idx=result$postprob.CpG>0.5 & result$postprob.GCcontent>0.5
    if(any(idx)) {
      pos=(result$pos.idx[idx]-1)*.CGIoptions$L+1
      postprob=data.frame(chr=chr, pos=pos, pp.GCcontent=result$postprob.GCcontent[idx],
        pp.CpG=result$postprob.CpG[idx])
      save(postprob, file=paste(.CGIoptions$result.dir,"/postprob-", chr,".rda",sep=""))
    }
  }

}


