#############################################################
## This file contains functions in chromosome level.
## All functions here work for a single chr.
#############################################################


##  HMM on C+G, given data file
## this works for one chromosome
HMM.GC.chr <- function(CleanFile, opts, param, Ngc) {
##  K <- opts$windowSize/8
  L <- opts$windowSize ##8*K
  chr <- gsub(".rda", "", gsub("cleandata.", "", CleanFile))
  ## chr <- strsplit(CleanFile, "\\.")[[1]][2]
  ## load in clean up data
  load(paste(opts$tmpDir,CleanFile,sep="/"))
  dat0 <- res0$dat; nn <- nrow(dat0)
  ll <-res0$ll
  if(missing(Ngc)) ## not given Ngc, use original data
    Ngc <- rowSums(dat0[,c("C","G")])

  resultfile <- paste(opts$tmpDir, "/result.GCcontent.",chr, ".rda", sep="")
  paramfile <- paste(opts$tmpDir, "/param.GCcontent.",chr,".rda", sep="")
  ## call engine function
  if(!missing(param)) { ## with parameters
    ## load saved parameters
    load(paste(opts$resultDir, "/allparam-GCcontent.rda", sep=""))
    result <- HMM.engine.GCcontent(Ngc, ll, L,
                                mu0=param$mu0,mu1=param$mu1,std=param$std,
                                init.prob=log(param$initprob),
                                trans.prob=log(param$transprob),
                                TOL=opts$EM.TOL,nmaxiter=1, verbose=FALSE)
    save(result, file=resultfile)
  }
  else {## no parameter, estimate from data
    result <- HMM.engine.GCcontent(Ngc, ll, L, TOL=opts$EM.TOL,
                                   nmaxiter=opts$EM.niter, verbose=FALSE)
##    result <- list(postprob=result$postprob, pos.idx=res0$pos.idx)
    param <- list(n=length(Ngc), mu0=result$mu0, mu1=result$mu1, std=result$std,
                  transprob=result$transprob,initprob=result$initprob)
    save(result, file=resultfile)
    save(param, file=paramfile)
  }
}

#########################################
##  HMM on CpG, given data file.
## this works for one chromosome
#########################################
HMM.CpG.chr <- function(CleanFile, opts, param) {
##  K <- opts$windowSize/8
  L <- opts$windowSize ##8*K
  chr <- gsub(".rda", "", gsub("cleandata.", "", CleanFile))
  ## chr <- strsplit(CleanFile, "\\.")[[1]][2]
  ## load in clean up data
  load(paste(opts$tmpDir,CleanFile,sep="/"))
##   dat0 <- res0$dat; nn <- nrow(dat0)
##   ll <-res0$ll
  Ncpg <- res0$dat[,"CG"]

  ## get denominator
  ## load result from G+C HMM
  resultfile <- paste(opts$tmpDir,paste("result.GCcontent.",chr, ".rda", sep=""),sep="/")
  load(resultfile)
  Xt <- result$postprob>0.5
  ## load ft file
  resultfile <- paste(opts$tmpDir,paste("ft.GCcontent.",chr, ".rda", sep=""),sep="/")
  load(resultfile)
  ## saved is Ngc0-f(t), compute f(t)
  Ngc0 <- rowSums(res0$dat[,c("C","G")])
  ft <- Ngc0-Ngc
  Xt <- result$postprob>0.5
  Pc <-  (result$mu0+(result$mu1-result$mu0)*Xt+ft)/2/L
  ## start calculation
  resultfile <- paste(opts$tmpDir, "/result.CpG.",chr, ".rda", sep="")
  paramfile <- paste(opts$tmpDir, "/param.CpG.",chr,".rda", sep="")
  ## call engine function
  if(!missing(param)) { ## with parameters
    ## load saved parameters
    load(paste(opts$resultDir, "/allparam-CpG.rda", sep=""))
    result <- HMM.engine.CpG(Ncpg, Pc, res0$ll, L,
                             l0=param$l0,l1=param$l1,
                             init.prob=log(param$initprob),
                             trans.prob=log(param$transprob),
                             TOL=opts$EM.TOL,nmaxiter=1, verbose=FALSE)
    result$Pc <- Pc ## save denominator for later use (likelihood ratio)
    save(result, file=resultfile)
  }
  else {## no parameter, estimate from data
    result <- HMM.engine.CpG(Ncpg, Pc, res0$ll, L, TOL=opts$EM.TOL,
                             nmaxiter=opts$EM.niter, verbose=FALSE)
    result$Pc <- Pc
    param <- list(n=length(Ngc), l0=result$l0, l1=result$l1,
                  transprob=result$transprob,initprob=result$initprob)
    save(result, file=resultfile)
    save(param, file=paramfile)
  }
}


