#include <math.h>
#include <stdlib.h>
#include <stdio.h>
#include <R.h>
#include <Rmath.h>
#include <R_ext/PrtUtil.h>
#define THRESH 200.0

void allocate_imatrix(int n_row, int n_col, int ***matrix);
void cpg_hmm_engine(int *npos, double *emitprob,      
                    double *initprob, double *trans_prob,       
                    int *Argmax);         
void calc_cpg_prob(int *npos, double *emitprob, 
                   double *initprob, double *trans_prob, int *flag,
                   double *postprob, double *post_trans_prob);
double addlog(double a, double b);


/* this is to use Viterbi to get the most probably path */
void cpg_hmm_engine(int *npos, double *emitprob, 
		    double *initprob, double *trans_prob,
		    int *Argmax) {
  int j, v, **traceback;
  double gamma[2], tmpgamma[2], s0, s1;

  int n_pos=*npos;
  allocate_imatrix(n_pos, 2, &traceback);

  /* begin viterbi algorithm */
  for(v=0; v<=1; v++)
    gamma[v] = initprob[v] + emitprob[v*n_pos];

  for(j=1; j<n_pos; j++) {
    for(v=0; v<=1; v++) { /* current stage is v */
      s0 = gamma[0] + trans_prob[2*v];
      s1 = gamma[1] + trans_prob[2*v+1];  
      if(s0>s1) { /* previous stage is 0 */
        tmpgamma[v] = s0;   
	traceback[j-1][v] = 0;  
      }
      else {
        tmpgamma[v] = s1;
	traceback[j-1][v] = 1;    
      }
      /* plus emission */
      tmpgamma[v] = tmpgamma[v] + emitprob[v*n_pos+j];
    } 
    /* update gamma */ 
    gamma[0] = tmpgamma[0];
    gamma[1] = tmpgamma[1];             
  }

  /* finish off viterbi and then traceback to get most 
     likely sequence of genotypes   
     find the last state:            */
  /* start from the last one */
  if(gamma[0] > gamma[1])
    Argmax[n_pos-1] = 0; 
  else 
    Argmax[n_pos-1] = 1;
  
  for(j=n_pos-2; j>=0; j--) {
    Argmax[j] = traceback[j][Argmax[j+1]];
  }

}


/* calculate posterior probability */
void calc_cpg_prob(int *npos, double *emitprob,
		   double *initprob, double *trans_prob, int *flag, 
		   double *postprob, double *post_trans_prob) {
  int i, j; 
  double s0, s1, ss, *alpha, *beta;

  /* allocate memory */
  alpha = (double *)R_alloc(2*(*npos), sizeof(double));
  beta = (double *)R_alloc(2*(*npos), sizeof(double)); 

  /* initialize alpha and beta */
  alpha[0] = emitprob[0] + initprob[0];
  alpha[*npos] = emitprob[*npos] + initprob[1]; 
  beta[(*npos)-1] = 0;
  beta[2*(*npos)-1] = 0;

  /* forward-backward */
  for(i=1; i<*npos; i++) {
    /* alpha */
    alpha[i] = emitprob[i] + addlog(alpha[i-1]+trans_prob[0],
				    alpha[*npos+i-1]+trans_prob[1]);
    alpha[i+(*npos)] = emitprob[i+(*npos)] + 
      addlog(alpha[i-1]+trans_prob[2],alpha[*npos+i-1]+trans_prob[3]);
    /* beta */
    j = (*npos) - i - 1;
    beta[j] = addlog(beta[j+1]+trans_prob[0]+emitprob[j+1],
		     beta[(*npos)+j+1]+trans_prob[2]+emitprob[(*npos)+j+1]);
		     
    beta[j+(*npos)] = addlog(beta[j+1]+trans_prob[1]+emitprob[j+1],
			     beta[(*npos)+j+1]+trans_prob[3]+emitprob[(*npos)+j+1]);
  }
  
  /* calculate posterior probability */
  for(i=0; i<*npos; i++) {
    s0 = alpha[i]+beta[i];
    s1 = alpha[*npos+i]+beta[*npos+i];
    ss = addlog(s0, s1);
    postprob[i] = exp(s1 - ss);
    /* compute posterior transition probability if requested */
    if(*flag) {
      if(i<(*npos-1)) { /* skip the last one */
	/* four columns are 0->0, 1->0, 0->1, 1->1,
	   in the same order as trans_prob */
	/* 0->0 */
	post_trans_prob[i] = exp(alpha[i]+emitprob[i+1]+beta[i+1]+trans_prob[0] - ss);
	/* 1->0 */
	post_trans_prob[(*npos)+i] = exp(alpha[*npos+i]+emitprob[i+1]+
				       beta[i+1]+trans_prob[1] - ss);
	/* 0->1 */                
	post_trans_prob[2*(*npos)+i] = exp(alpha[i]+emitprob[*npos+i+1]+beta[*npos+i+1]+
					   trans_prob[2] - ss);
	/* 0->1 */      
	post_trans_prob[3*(*npos)+i] = exp(alpha[*npos+i]+emitprob[*npos+i+1]+beta[*npos+i+1]+ 
					   trans_prob[3] - ss); 
      }
    }
  }

}


void allocate_imatrix(int n_row, int n_col, int ***matrix)
{
  int i;

  *matrix = (int **)R_alloc(n_row, sizeof(int *));
  (*matrix)[0] = (int *)R_alloc(n_col*n_row, sizeof(int));
  for(i=1; i<n_row; i++)
    (*matrix)[i] = (*matrix)[i-1]+n_col;
}

double addlog(double a, double b) 
{
  if(b > a + THRESH) return(b);
  else if(a > b + THRESH) return(a);
  else return(a + log1p(exp(b-a)));
}
