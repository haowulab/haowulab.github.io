### given counts calculate posterior probabilities of
## being CGI and save

calc.postprob <- function() {
  ## read in repeats
  if(!is.null(.CGIoptions$repeat.file)) {
    repeats <- read.table(.CGIoptions$repeat.file, header=TRUE,sep="\t")
    colnames(repeats) <- c("chr","start","end")
    save(repeats, paste(.CGIoptions$tmpdir,"/repeats.rda",sep=""))
  }
  else
    repeats=NULL
  ## get the list of counts
  count.files=dir(.CGIoptions$tmpdir, patter="Counts-")
  ## step 1: run forward-backward with EM
  cat("Forward-backward with EM:\n")
  for(ff in count.files) {
    load(paste(.CGIoptions$tmpdir,ff,sep="/"))
    assign("dat", get(ls(pattern="Counts")))
    rm(list=ls(pattern="Counts"))
    chr <- base:::substr(unlist(strsplit(ff,"\\."))[1],8,1000)
    cat("\n########", chr, "########:\n\n")
    ## run EM with HMM
    repeats.chr <- repeats[repeats$chr==chr,]
    result <- findCpG.noalu.engine.all(dat, repeats.chr, CG.equal=TRUE,
                                       N=.CGIoptions$L,K=1,wsize=5)
    
    ## save
    fname <- paste(.CGIoptions$tmpdir,"/EM.result-", chr, ".rda", sep="")
    save(result, file=fname)
  }
  
  ## step 2: calculate aggregated parameters (init/trans/emit probabilites)
  ## based on results from all chromosomes
  cat("Calculate parameters ... \n")
  getAllParam()
  
  ## step 3: run forward-backward with estimated parameters
  load(paste(.CGIoptions$tmpdir,"/allparam.rda",sep=""))
  cat("\n\nFinal forward-back:\n")
  for(ff in count.files) {
    load(paste(.CGIoptions$tmpdir,ff,sep="/"))
    assign("dat", get(ls(pattern="Counts")))
    rm(list=ls(pattern="Counts"))
    chr <- base:::substr(unlist(strsplit(ff,"\\."))[1],8,1000)
    cat("\n########", chr, "########:\n\n")
    ## run EM with HMM
    repeats.chr <- repeats[repeats$chr==chr,]
    result <- findCpG.noalu.engine.all(dat, repeats.chr, CG.equal=TRUE,
                                       N=.CGIoptions$L,K=1,wsize=5,
                                       l0=l0,l1=l1,mu0=mu0,mu1=mu1,std=std,
                                       init.prob.CpG=log(initprob.CpG),
                                       trans.prob.CpG=log(transprob.CpG),
                                       init.prob.GCcontent=log(initprob.GCcontent),
                                       trans.prob.GCcontent=log(transprob.GCcontent),
                                       nmaxiter=1)

    ## grab the section where both posterior probabilites bigger than 0.5
    idx=result$postprob.CpG>0.5 & result$postprob.GCcontent>0.5
    if(any(idx)) {
      pos=(result$pos.idx[idx]-1)*.CGIoptions$L+1
      postprob=data.frame(chr=chr, pos=pos, pp.GCcontent=result$postprob.GCcontent[idx],
        pp.CpG=result$postprob.CpG[idx])
      save(postprob, file=paste(.CGIoptions$result.dir,"/postprob-", chr,".rda",sep=""))
    }
  }
  
}

  
### function to get aggregated parameters
getAllParam <- function() {
  ## init
  totaln <- 0
  l0 <- l1 <- mu0 <- mu1 <- std <- 0
  initprob.CpG <- initprob.GCcontent <- rep(0,2)
  transprob.CpG <- transprob.GCcontent <- matrix(0, 2,2)

  ## forward-backward files
  files=dir(.CGIoptions$tmpdir, patter="EM.result-")
  nfiles <- length(files)
  all.mu0 <- all.mu1 <- all.std <- all.l0 <- all.l1 <- rep(0, nfiles)
  all.initprob.CpG <- all.initprob.GCcontent <- matrix(0, nrow=2, ncol=nfiles)
  all.transprob.CpG <- all.transprob.GCcontent <- array(0, dim=c(2,2,nfiles))
  all.n <- rep(0, nfiles)
  all.chr <- rep("", nfiles)

  ## loop on result files
  for(i in seq(along=files)) {
    chr <- base:::substr(unlist(strsplit(files[i],"\\."))[2], 8,1000)
    cat(chr, ",")
    load(paste(.CGIoptions$tmpdir, "/", files[i], sep=""))

    all.chr[i] <- chr
    all.n[i] <- length(result$postprob.CpG)
    all.l0[i] <- result$l0
    all.l1[i] <- result$l1
    all.mu0[i] <- result$mu0
    all.mu1[i] <- result$mu1
    all.std[i] <- result$std
    
    all.initprob.CpG[,i] <- result$initprob.CpG
    all.transprob.CpG[,,i] <- result$transprob.CpG
    all.initprob.GCcontent[,i] <- result$initprob.GCcontent
    all.transprob.GCcontent[,,i] <- result$transprob.GCcontent
  }

  ## average across chromosomes
  l0 <- sum(all.l0*all.n) / sum(all.n)
  l1 <- sum(all.l1*all.n) / sum(all.n)
  mu0 <- sum(all.mu0*all.n) / sum(all.n)
  mu1 <- sum(all.mu1*all.n) / sum(all.n)
  std <- sum(all.std*all.n)/sum(all.n)
  
  ## init prob
  for(i in 1:2) {
    initprob.CpG[i] <- sum(all.initprob.CpG[i,]*all.n) / sum(all.n)
    initprob.GCcontent[i] <- sum(all.initprob.GCcontent[i,]*all.n) / sum(all.n)
  }
  ## trans prob
  for(i in 1:length(all.n)) {
    ## cpg
    transprob.CpG <- transprob.CpG + all.transprob.CpG[,,i]*all.n[i]
    ## gc content
    transprob.GCcontent <- transprob.GCcontent + all.transprob.GCcontent[,,i]*all.n[i]
  }
  transprob.CpG <- transprob.CpG / sum(all.n)
  transprob.GCcontent <- transprob.GCcontent / sum(all.n)

  ## save
  save(l0, l1, mu0, mu1, std, initprob.CpG, transprob.CpG,
       initprob.GCcontent, transprob.GCcontent,
       file=paste(.CGIoptions$tmpdir,"/allparam.rda",sep=""))
}
