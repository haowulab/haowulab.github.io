## function to make a list of bumps
## given score and cutoff
findBumps <- function(chr, pos, x, cutoff, sep=2000,
                      minlen=100, minCount=3, dis.merge=100) {
  flag <- as.numeric(x>cutoff)
  flag[is.na(flag)]=FALSE 
  ## find regions
  regions <- findRegion(chr, pos, sep)
  ## loop on regions
  initn <- 5000
  result <- data.frame(chr=rep("chr1",initn), start=rep(0,initn),
                       end=rep(0, initn), length=rep(0, initn))
  levels(result[,1]) <- unique(chr)
  result.idx <- 0
  for(i in 1:ncol(regions)) {
    idx <- regions[1,i]:regions[2,i]
    pos.region <- pos[idx]
    if(length(idx)<minCount) next
    nn <- length(idx)
    flag.region <- flag[idx]
    ## get start/end position
    startidx <- which(flag.region[-nn]==0 & flag.region[-1]==1)+1
    if(flag.region[1]==1)
      startidx <- c(1, startidx)
    if(length(startidx)==0)
      next
    endidx <- which(flag.region[-nn]==1 & flag.region[-1]==0)
    if(flag.region[nn]==1)
      endidx <- c(endidx, nn)

    ## remove if there are less than minCount probes
    idx.keep <- (endidx-startidx+1)>=minCount
    startidx <- startidx[idx.keep]
    endidx <- endidx[idx.keep]
    if(length(endidx)==0) next

    ## merge if they are really close
    nbump <- length(startidx)
    if(nbump>1) {
      bumppos <- cbind(pos[idx][startidx], pos[idx][endidx])
      dis <- bumppos[-1,1]>(bumppos[-nbump,2]+dis.merge)
      idx.start <- which(c(1,dis)==1)
      idx.end <- which(c(dis,1)==1)
      ## merged
      startidx <- startidx[idx.start]
      endidx <- endidx[idx.end]
    }
    nbump <- length(startidx)
    ll <- pos.region[endidx] - pos.region[startidx] + 1
    tmpn <- length(ll)
    result[result.idx+(1:tmpn),] <- data.frame(chr=as.character(chr[idx][startidx]),
                                               start=pos[idx][startidx],
                                               end=pos[idx][endidx], length=ll)
    result.idx <- result.idx + tmpn
  }
  
  result <- result[1:result.idx,]
  ## remove really short ones
  result <- result[result[,4]>minlen,]
  result
}
