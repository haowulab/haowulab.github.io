## general function to fit mixture of two poissons
## Y doesn't have to be integers
mix.2pois <- function(Y,pi=0.5, nmaxiter=100, TOL=1e-8*length(Y)) {
  n <- length(Y)
  sorty <- sort(Y)
  
  ## get initial values using pi0=0.5
  n0 <- round(n*pi)
  lambda1 <- mean(sorty[1:n0])
  lambda2 <- mean(sorty[(n0+1):n])
  loglik.old <- 0
  tmp <- weights <- matrix(0, length(Y), 2)
  
  for(i in 1:nmaxiter) {
    ## E-step: calculate responsibilities
    weights[,1] <- lambda1^Y*exp(-lambda1) ##dpois(Y, lambda1)
    weights[,2] <- lambda2^Y*exp(-lambda2) ##dpois(Y, lambda2)
    tmp <- sweep(weights, 2, c(1-pi, pi), "*")
    ll<- rowSums(tmp)
    gamma <- sweep(tmp, 1, ll, "/")
    loglik <- sum(log(ll))
    if(abs(loglik-loglik.old) < TOL)
      break
    loglik.old <- loglik

    s <- sum(gamma[,2])
    ## M-step: update mu's and sd's
    lambda1 <- sum(gamma[,1]*Y)/(n-s)
    lambda2 <- sum(gamma[,2]*Y)/s
    pi <- s/n
    cat(i, "loglik=", loglik,": lambda1=", lambda1,
        ", lambda2=", lambda2, ", pi=", pi, "\n")
  }

  ## return a list
  list(lambda1=lambda1, lambda2=lambda2, pi=pi)
}

## function to fit my needs for 2 pois
mix.2pois2 <- function(Y, Pcgs, N, pi=0.5, nmaxiter=100, TOL=1e-8*length(Y)) {
  n <- length(Y)
##  sorty <- sort(Y)
  
  ## get initial values using pi0=0.5
  alpha1 <- 0.2
  alpha2 <- 1
  loglik.old <- 0
  tmp <- weights <- matrix(0, length(Y), 2)
  
  for(i in 1:nmaxiter) {
    ## E-step: calculate responsibilities
    lambda1 <- alpha1*Pcgs*N
    lambda2 <- alpha2*Pcgs*N
    weights[,1] <- dpois(Y, lambda1)
    weights[,2] <- dpois(Y, lambda2)
    tmp <- sweep(weights, 2, c(1-pi, pi), "*")
    ll<- rowSums(tmp)
    gamma <- sweep(tmp, 1, ll, "/")
    loglik <- sum(log(ll))
    if(abs(loglik-loglik.old) < TOL)
      break
    loglik.old <- loglik

    ## M-step: update mu's and sd's
    alpha1 <- sum(gamma[,1]*Y)/sum(gamma[,1]*Pcgs)/N
    alpha2 <- sum(gamma[,2]*Y)/sum(gamma[,2]*Pcgs)/N
    s <- sum(gamma[,2])
    pi <- s/n
    cat(i, "loglik=", loglik,": alpha1=", alpha1,
        ", alpha2=", alpha2, ", pi=", pi, "\n")
  }

  ## return a list
  list(alpha1=alpha1, alpha2=alpha2, pi=pi, gamma=gamma)
}


## simple function for two component normal mixture
mix.2norm <- function(Y, pi=0.5, nmaxiter=100, TOL=1e-10*length(Y),
                      var.eq=TRUE) {
  n <- length(Y)
  sorty <- sort(Y)
  
  ## get initial values using pi0=0.5
  n0 <- round(n*pi)
  sd1 <- sd2 <- sd(Y)
  mu1 <- mean(sorty[1:n0])
  mu2 <- mean(sorty[(n0+1):n])
  tmp <- weights <- matrix(0, length(Y), 2)
  loglik.old <- 0
  
  for(i in 1:nmaxiter) {
    ## E-step: calculate responsibilities
    weights[,1] <- dnorm(Y, mu1, sd1)
    weights[,2] <- dnorm(Y, mu2, sd2)
    tmp <- sweep(weights, 2, c(1-pi, pi), "*")
    ll<- rowSums(tmp)
    gamma <- sweep(tmp, 1, ll, "/")
    loglik <- sum(log(ll))
    if(abs(loglik-loglik.old) < TOL)
      break
    loglik.old <- loglik

    s <- sum(gamma[,2])
    ## M-step: update mu's and sd's
    mu1 <- sum(gamma[,1]*Y)/(n-s)
    mu2 <- sum(gamma[,2]*Y)/s
    if(var.eq) {
      sd1 <- sd2 <- sqrt((sum(gamma[,1]*(Y-mu1)^2)+sum(gamma[,2]*(Y-mu2)^2))/n)
    }
    else {
      sd1 <- sqrt(sum(gamma[,1]*(Y-mu1)^2)/(n-s))
      sd2 <- sqrt(sum(gamma[,2]*(Y-mu2)^2)/s)
    }
    pi <- s/n
    cat(i, "loglik=", loglik,": mu1=", mu1, ", mu2=",
        mu2, "sd1=", sd1, "sd2=",sd2,"\n")
  }

  ## return a list
  list(mu1=mu1, mu2=mu2, sd1=sd1, sd2=sd2, pi=pi)
}


  
### ## function to calculate multivariate normal density
mvdnorm <- function(data, mean, sigma) {
  ## if data is one observation, make it a matrix
  if(class(data) == "numeric")
    data <- matrix(data, nrow=1)
  
  p <- dim(data)[2]
  
  ## log determinent of sigma
  logdet <- sum(log(eigen(sigma, symmetric=TRUE,
                          only.values=TRUE)$values))
  ## Mahalanobis Distance between data and mean
  distval <- apply(data, 1, function(x) mahalanobis(x, mean,sigma))
  ## log-density
  logretval <- -(p*log(2*pi) + logdet + distval)/2
  ## exponential and return
  exp(logretval)
}

## another way to calculate it. This is only for one observations
mvdnorm2 <- function(data, mean, sigma) {
  ## f(X)
  fx <- dnorm(data[1], mean[1], sqrt(sigma[1,1]))
  
  ## f(Y|X)
  Ey <- mean[2] + sigma[1,2]/sigma[1,1]*(data[1]-mean[1])
  Vy <- sigma[2,2] - sigma[1,2]^2/sigma[1,1]
  fy.x <- dnorm(data[2], Ey, sqrt(Vy))
  
  fx * fy.x
}



## function to fit normal mixture model using EM
## this function is slow, I should modify it a little
em.norm.mix <- function(dat, init.idx, pi.grp2=0.5, nmaxiter=100, TOL=1e-3) {
  if(is.vector(dat)) # make it a matrix
    dat <- matrix(dat, ncol=1)
  n <- dim(dat)[1] # number of observations
  ## update tolerence, it should depends on samplesize
  TOL <- TOL * (n/100)
  
  ##### calculate initial values #####
  ## first group
  mu1 <- apply(dat[init.idx,,drop=F], 2, mean) # mean
  sigma1 <- cov(dat[init.idx,,drop=F])
  ## second group
  mu2 <- apply(dat[!init.idx,,drop=F], 2, mean) # mean
  sigma2 <- cov(dat[!init.idx,,drop=F])
  
##### start EM #######
  loglik.old <- 0
  tmp <- weights <- matrix(0, nrow(dat), 2)
  for(i in 1:nmaxiter) {
    ## E-step: calculate E[Z|(X,Y)]
    if(ncol(dat)==1) {
      weights[,1] <- dnorm(dat, mu1, sqrt(sigma1))
      weights[,2] <- dnorm(dat, mu2, sqrt(sigma2))
    }
    else {
                                        #     weights[,1] <- mvdnorm(dat, mu1, sigma1)
                                        #     weights[,2] <- mvdnorm(dat, mu2, sigma2)
      weights[,1] <- apply(dat, 1, function(x) mvdnorm2(x, mu1, sigma1))
      weights[,2] <- apply(dat, 1, function(x) mvdnorm2(x, mu2, sigma2))
    }
    tmp[,1] <- weights[,1]*(1-pi.grp2)
    tmp[,2] <- weights[,2]*pi.grp2
    ll<- rowSums(tmp)
    gamma <- sweep(tmp, 1, ll, "/") ## now gamma are responsibilities
    s <- sum(gamma[,2]) ## total responsibilities for group 2
    loglik <- sum(log(ll))
    ## check for convergence
    if(abs(loglik-loglik.old) < TOL)
      break
    loglik.old <- loglik
    
    ## M-step: update mu's and sigma's
    ## - these are calculated as the weighted mean and var
    mu1 <- apply(dat, 2, function(x) weighted.mean(x, gamma[,1]))
    sigma1 <- cov.wt(dat, gamma[,1],center=mu1)$cov
    mu2 <- apply(dat, 2, function(x) weighted.mean(x, gamma[,2]))
    sigma2 <- cov.wt(dat, gamma[,2],center=mu2)$cov
    
    ## update pi
    pi.grp2 <- s/n
    cat(i, "loglik=", loglik, "\n")
  }
  list(mu1=mu1, sigma1=sigma1, mu2=mu2, sigma2=sigma2, pi=pi.grp2,
       gamma=gamma, loglik=loglik)
}



### function to fit mixture of normal using EM
em.mixture <- function(dat, init.idx, pi0, ngrp=2, nmaxiter=100, TOL=1e-2,
                       Xdist=c("Gamma", "Gaussian"), df=3,
                       equal.errorvar=FALSE) {
  require(splines)
  ## dat should be a matrix
  if(class(dat)!="matrix")
    stop("Input dat should be a matrix")

  Xdist <- match.arg(Xdist)

  n <- dim(dat)[1] # number of observations
  ## update tolerence, it should depends on samplesize
  TOL <- TOL * (n/100)

  if(missing(pi0)) ## initial value for pi
    pi0 <- rep(1/ngrp, ngrp)

  ## check init.idx - it should be a matrix of n x ngrp booleans

  #### create basis matrix - I assume dat has two columns now
  xbasis <- ns(dat[,2], df=df)
  newdata <- as.data.frame(dat[,2])
  ##### calculate initial values #####
  mux <- sdx <- sdy <- scale <- shape <- rep(0, ngrp)
  fx <- vector("list", ngrp)
  for(k in 1:ngrp) {
    if(Xdist=="Gamma") {
      ## estimate shape and scale
      mm <- mean(dat[init.idx[,k],2])
      vv <- var(dat[init.idx[,k],2])
      scale[k] <- vv/mm
      shape[k] <- mm/scale[k]
    }
    else if(Xdist=="Gaussian") {
      ## estimate mean and sd
      mux[k] <- mean(dat[init.idx[,k],2])
      sdx[k] <- sqrt(var(dat[init.idx[,k],2]))
    }
    fx[[k]] <- lm(dat[,1]~xbasis, subset=init.idx[,k])
    sdy[k] <- sqrt(mean(residuals(fx[[k]])^2))
  }
  if(equal.errorvar)
    sdy[1:ngrp] <- mean(sdy)

  ##### start EM #######
  loglik.old <- 0
  tmp <- densities <- matrix(NA, nrow(dat), ngrp)
  probs <- pi0
  for(i in 1:nmaxiter) {
    ## E-step: calculate E[Z|(X,Y)]
    for(k in 1:ngrp) {
      if(Xdist=="Gamma") {
        den.x <- dgamma(dat[,2], shape[k], scale=scale[k])
      }
      else if(Xdist=="Gaussian")  {
        den.x <- dnorm(dat[,2], mux[k],sdx[k]) ## Pr(X)
      }

      pred <- predict(fx[[k]], newdata=newdata)
      ## Pr(Y|X)
      den.y <- dnorm(dat[,1], pred, sdy[k])
      densities[,k] <- den.x * den.y
    }
    gamma <- sweep(densities, 2, probs, "*")
    ll<- rowSums(gamma)
    gamma <- sweep(gamma, 1, ll, "/") ## now gamma are responsibilities
    loglik <- sum(log(ll))
    ## check for convergence
    if(abs(loglik-loglik.old) < TOL)
      break
    loglik.old <- loglik

    ## M-step: update estimations
    ## - these are calculated as the weighted mean and var and lm
    rss <- 0
    for(k in 1:ngrp) {
      if(Xdist=="Gamma") {
        mm <- weighted.mean(dat[,2], gamma[,k])
        vv <- cov.wt(dat[,2,drop=F], gamma[,k])$cov
        scale[k] <- vv/mm
        shape[k] <- mm/scale[k]
      }
      else if(Xdist=="Gaussian") {
        mux[k] <- weighted.mean(dat[,2], gamma[,k])
        sdx[k] <- sqrt(cov.wt(dat[,2,drop=F], gamma[,k])$cov)
      }

      fx[[k]] <- lm(dat[,1]~xbasis, weights=gamma[,k])
      sdy[k] <- sqrt(sum(gamma[,k]*residuals(fx[[k]])^2)/sum(gamma[,k]))
    }
    if(equal.errorvar)
      sdy[1:ngrp] <- mean(sdy)

    ## update pi
    probs <- colMeans(gamma)
    cat(i, "loglik=", loglik, "\n")
  }

  ## return
  if(Xdist=="Gamma")
    result <- list(scale=scale, shape=shape, fx=fx, sdy=sdy, gamma=gamma,
                   pi=probs, densities=densities)
  else if(Xdist=="Gaussian")
    result <- list(mux=mux, sdx=sdx, fx=fx, sdy=sdy, gamma=gamma,
                   pi=probs, densities=densities )

  invisible(result)
}

