## read in sequence files and count C, G and CG for each
## L bp window
require(BSgenome)
count.CG <- function() {
  cat("count C and G in each bin:")
  if(.CGIoptions$rawdat.type=="txt") { ## text files for sequence
    nchr=length(.CGIoptions$files)
    for(ichr in 1:nchr) {
      chr=names(.CGIoptions$files[ichr])
      cat(chr, ",")
      tmp=scan(paste(.CGIoptions$rawdat.dir,"/",.CGIoptions$files[ichr],sep=""),
        what="character")
      tmp2=paste(tmp, collapse="")
      Seq=DNAString(tmp2)
      save(Seq, file=paste(.CGIoptions$tmpdir,"/Seq-",chr,".rda",sep=""))
      ## count for every L bp window
      Counts=do.Count(Seq, .CGIoptions$L)
      ## save
      save(Counts, file=paste(.CGIoptions$tmpdir,"/Counts-",chr,".rda",sep=""))
    }
  }

  else if(.CGIoptions$rawdat.type=="BSgenome") { ## from BSgenome package
    library(.CGIoptions$package,character=TRUE)
    dat=get(.CGIoptions$species)
    nchr=length(seqnames(dat))
    for(ichr in 1:nchr) {
      chr=seqnames(dat)[ichr]
      cat(chr, ",")
      Seq=DNAString(dat[[ichr]])
      ## count for every L bp window
      Counts=do.Count(Seq, .CGIoptions$L)
      ## save
      save(Counts, file=paste(.CGIoptions$tmpdir,"/Counts-",chr,".rda",sep=""))
    }
  }
  cat("\n")
}

## Count number of C, G and CG for each L bp window
do.Count <- function(Seq, w) {
  X = c("CG", "C", "G", "N")
  XX = length(X)

  L = length(Seq)
  W = L%/%w   # number of whole windows
  L.w = L%%w  # L modulo w
  WW = W + ifelse(L.w == 0, 0, 1)
  counts = integer(WW*XX)
  dim(counts) = c(WW,XX)
  colnames(counts) = X 
  counts[,XX] = as.integer(rep(w,WW))
  if (L.w != 0)
    counts[WW,XX] = as.integer(L%%w)
  for (j in seq(along=X)) {
    counts[,j] = bins(start(matchPattern(X[j], Seq)), WW, w)
  }
  counts
}
      
tabulate2 <- function(bin, WW) {
  .C("R_tabulate",
     as.integer(bin),
     as.integer(length(bin)),
     as.integer(WW),
     ans = integer(WW),
     NAOK=TRUE, DUP=FALSE,   # for efficiency
     PACKAGE = "base")$ans
}

bins <- function(a, WW, w) {
  tabulate2(a%/%w + ifelse(a%%w == 0, 0, 1), WW)
}
