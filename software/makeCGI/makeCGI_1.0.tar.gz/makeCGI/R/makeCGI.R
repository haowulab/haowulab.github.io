### make CGI list from posterior probabilities
makeCGI <- function(cutoff) {
  pp.files=dir(.CGIoptions$result.dir, patter="postprob-", full.name=TRUE)
  if(length(pp.files)==0) {
    cat("No CGI for this species.\n")
    return(NULL)
  }
    
  cgi <- NULL
  for(i in 1:length(pp.files)) {
    load(pp.files[i])
    tmp <- makeCGI.engine(postprob, cutoff)
    cgi <- base:::rbind(cgi, tmp)
  }
  cgi
}


makeCGI.engine <- function(postprob, cutoff) {
  sep <- .CGIoptions$L+1
  flag <- postprob[,"pp.GCcontent"]>cutoff & postprob[,"pp.CpG"]>cutoff
  flag[is.na(flag)] <- FALSE
  postprob <- postprob[flag,]
  ## find bumps
  bumps <- findBumps(postprob[,"chr"], postprob[,"pos"], rep(1, nrow(postprob)),0.95,
                     sep=sep, minlen=50, minCount=3, dis.merge=1)

  ## locate the exact start/end position of CGI
  bumps <- trim.CGI(bumps, .CGIoptions$rawdat.type)
  
  ## add other information from cisgenome - skip it for now
  bumps
}

### trim CGI using text
trim.CGI <- function(bumps0, format=c("txt","BSgenome")) {
  format <- match.arg(format)
  if(format=="BSgenome") {
    library(.CGIoptions$package,character=TRUE)
    dat=get(.CGIoptions$species)
  }  

  idx.throw=NULL
  ## init results
  cpgtable <- data.frame(bumps0, NA,NA,NA,NA)
  colnames(cpgtable) <- c("chr", "start", "end", "length",
                          "CpGcount", "GCcontent", "pctGC", "obsExp")

  idx=split(1:nrow(bumps0), bumps0[,"chr"])

  for(i in 1:length(idx)) { ## loop on chromosomes
    if(length(idx[[i]]) == 0)
      next
    chr=names(idx[i])
    cat(chr, ",")
    ## get sequence for this chromosome
    if(format=="txt")
      load(paste(.CGIoptions$tmpdir,"/Seq-",chr,".rda",sep=""))
    else
      Seq=dat[[chr]]

    ## check whether cgi go beyond the boundary
    nn <- length(Seq)
    ncpg <- idx[[i]][length(idx[[i]])] ## location of last cgi for this chromosome
    if(cpgtable[ncpg,"end"] > nn)
      cpgtable[ncpg,"end"] <- nn
    ## for each bump on this chromosome
    for(ibump in idx[[i]]) {
      rr=(cpgtable[ibump,"start"]-1):(cpgtable[ibump,"end"]+1)
      subseq <- Seq[rr]
      tmp <- matchPattern("CG",subseq)
      if(length(tmp)<3) {
        idx.throw <- c(idx.throw, ibump)
        next
      }
      ## true start/end
      cpgtable[ibump,"start"] <- cpgtable[ibump,"start"]+start(tmp)[1]-2
      cpgtable[ibump,"end"] <- cpgtable[ibump,"start"]+end(tmp)[length(tmp)]-1
      cpgtable$length <- cpgtable$end-cpgtable$start+1
      ## add other information
      cpgtable[ibump, c("CpGcount","GCcontent", "pctGC", "obsExp")] <-
          add.GCinfo(Seq, cpgtable[ibump,"start"], cpgtable[ibump,"end"])
    }
  }

  if(!is.null(idx.throw)) ## throw away junk ones
    cpgtable <- cpgtable[-idx.throw,]

  cpgtable[cpgtable$CpGcount>3,]
}
