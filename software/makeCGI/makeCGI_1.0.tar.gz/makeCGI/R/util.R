## moving window apply
mwapply <- function(x, size=10, step=3, FUN) {
  FUN <- match.fun(FUN)
  n <- length(x)
  result <- rep(NA, n)
  if(n >2*size) {
    for(i in seq(size+1,n-size, by=step)) {
      tmp <- FUN(x[(i-size):(i+size)])
      result[i:(i+step-1)] <- tmp
    }
    ## assign the starting and ending results
    result[1:size] <- result[size+1]
    result[(n-size):n] <- result[n-size]
  }
  else { ## if n smaller than window size, return one step result
    tmp <- FUN(x)
    result <- rep(tmp, n)
  }
  result
}



### a function to plot cpg results
compare.cpg <- function(dat, chr, start, end, FN=50, mycpg, bfcpg, curcpg) {
  nn <- nrow(dat)
  tmpn <- 2*FN + 1
  fs <- rep(1,tmpn)/tmpn

  ## find index
  start.idx <- floor(start/8)
  end.idx <- ceiling(end/8)

  dat0 <- dat[start.idx:end.idx,]
  
  ## grab a bigger piece of data
  start.true <- max(start.idx-100,1)
  end.true <- min(end.idx+100,nn)
  dat1 <- dat[start.true:end.true,]
  xidx <- (start.true:end.true)*8
  mypar(4,1)
  
  ## number of C and G
  ncandg <- rowSums(dat1[,4:5])
  plot(xidx, ncandg, type="h", main="Number of C and G")
  ncandg.smooth <- filter(ncandg, fs)
  ncandg.smooth[1:FN] <- ncandg.smooth[FN+1]
  ncandg.smooth[(length(ncandg.smooth)-FN+1):length(ncandg.smooth)] <-
    ncandg.smooth[length(ncandg.smooth)-FN]
  lines(xidx, ncandg.smooth, lwd=3, col="red")
  abline(h=4, lty=2, lwd=2)
  
  ## number of CG
  ncg <- dat1[,1]
  plot(xidx, ncg, type="h", main="Number of CG")
  ncg.smooth <- filter(ncg, fs)
##   ncg.smooth[1:FN] <- ncg.smooth[FN+1]
##   ncg.smooth[(length(ncg.smooth)-FN+1):length(ncg.smooth)] <-
##     ncg.smooth[length(ncg.smooth)-FN]
##   lines(ncg.smooth, lwd=3, col="red")

  ## obs CG / exp CG
  pc <- filter(dat1[,4], fs) / 8
  pg <- filter(dat1[,5], fs) / 8
  cg.ratio <- ncg.smooth/(pc*pg*8)
  ##cg.ratio <- ncg/(pc*pg*8)
  plot(xidx, cg.ratio, type="h", main=expression(Obs[CG]/Exp[CG]), xlab="")
  abline(h=0.55, lty=2, lwd=2)
  
  ## plot several lines for different cpg definition
  v <- c(start, end)
  ## my cpg
  ii <- overlap.vm(v, mycpg)
  plot(as.numeric(mycpg[ii,]), rep(1,2), ylim=c(0.8, 4),
       xlim=range(xidx), type="n", xaxt="n", yaxt="n", xlab="", ylab="")
  
  for(i in ii) {
    lines(as.numeric(mycpg[i,]), rep(1,2), lwd=10, col="black")
  }
  ## bf cpg
  ii <- overlap.vm(v, bfcpg)
  for(i in ii) {
    lines(as.numeric(bfcpg[i,]), rep(2,2), lwd=10, col="red")
  }
  ## current cpg
  ii <- overlap.vm(v, curcpg)
  for(i in ii) {
    lines(as.numeric(curcpg[i,]), rep(3,2), lwd=10, col="blue")
  }
  legend("topright", legend=c("my", "bf", "current"), lty=rep(1,3), lwd=3,
         col=c("black", "red", "blue"))
}


#################################################################
## a function to take away alu and other repeats from raw data
##################################################################
data.takerpt <- function(dat, alu, N) {
  Nidx <- makelistN(dat[,"N"], round(N*0.7))
  if(!is.null(alu)) {
    aluidx.chr <- round(alu/N)
    colnames(aluidx.chr) <- c("start", "end")
  }
  else 
    aluidx.chr <- NULL

  ## note Nidx and aluidx.chr should have no overlap
  idx.remove <- base:::rbind(Nidx, aluidx.chr)
  if(is.null(idx.remove)) { ## nothing to remove
    leftover.idx <- matrix(c(1, dim(dat)[1]), nrow=1)
  }
  else { ## need to remove something
    idx.remove <- idx.remove[sort(idx.remove[,1], index.return=TRUE)$ix,]
    ## make indices for leftover pieces
    startidx <- c(1, idx.remove[,2]+1)
    endidx <- c(idx.remove[,1]-1, dim(dat)[1])
    leftover.idx <- base:::cbind(startidx, endidx)
  }
  ## remove if the leftover piece is too small
  ll <- leftover.idx[,2] - leftover.idx[,1] + 1
  idx <- ll>(100/N)
  leftover.idx <- leftover.idx[idx,,drop=FALSE]
  ll <- ll[idx]
  ## grab data without alu
  nn <- sum(ll)
  allidx <- rep(0, nn)
  idx <- 0
  for(i in 1:dim(leftover.idx)[1]) {
    tmpidx <- leftover.idx[i,1]:leftover.idx[i,2]
    allidx[idx+(1:length(tmpidx))] <- tmpidx
    idx <- idx + length(tmpidx)
  }
  ## data with alu removed
  list(dat=dat[allidx,], ll=ll, pos.idx=allidx)
}

  
##########################################################
## filter cpg islands. this is arbitrary
## not seq for the current chr must be in place
##########################################################

filterCpG <- function(from, to, thresh=0.5) {
  subseq<-seq[from:to]
  nc <- length(start(matchPattern("C",subseq)))
  if(nc==0) return(FALSE)
  ng <- length(start(matchPattern("G",subseq)))
  if(ng==0) return(FALSE)
  ncg <- length(start(matchPattern("CG",subseq)))
  if(ncg==0) return(FALSE)
  
  nn <- length(subseq)
  ratio <- (ncg*nn)/(nc*ng)
  if(ratio>thresh)
    return(TRUE)
  else 
    return(FALSE)
}

##########################################################
## grab infor like gc content, cg counts
## output is c(#CpG, #G.C, %GC, obsExp)
##########################################################
add.GCinfo <- function(seq, from, to) {
  nn <- length(from)
  if(nn==1) {
    if(to > length(seq))
      to <- length(seq)
    subseq<-seq[from:to]
    nc <- length(start(matchPattern("C",subseq)))
    ng <- length(start(matchPattern("G",subseq)))
    ncg <- length(start(matchPattern("CG",subseq)))
    
    nn <- length(subseq)
    pctGC <- (nc+ng)/nn
    ratio <- (ncg*nn)/(nc*ng)
    res <- c(ncg, nc+ng, pctGC, ratio)
  }
  else {
    res <- matrix(0, nrow=nn, ncol=4)
    for(i in 1:nn) {
      if(to[i] > length(seq))
        to[i] <- length(seq)
      subseq<-seq[from[i]:to[i]]
      nc <- length(start(matchPattern("C",subseq)))
      ng <- length(start(matchPattern("G",subseq)))
      ncg <- length(start(matchPattern("CG",subseq)))
      nn <- length(subseq)
      pctGC <- (nc+ng)/nn
      ratio <- (ncg*nn)/(nc*ng)
      res[i,] <- c(ncg, nc+ng, pctGC, ratio)
    }
  }
  res
}

###############################################
## filter taking care of edges
###############################################

myfilter <- function(x,filter,...){
  res=filter(x,filter,...)
  ##now fill out the NAs
  M=length(filter)
  N=(M- 1)/2
  L=length(x)
  for(i in 1:N){
    w=filter[(N-i+2):M]
    y=x[1:(M-N+i-1)]
    res[i] = sum(w*y)/sum(w)
    
    w=rev(w)
    ii=(L-(i-1))
    y=x[(ii-N):L]
    res[ii]<-sum(w*y)/sum(w)
  }
  return(res)
}

########################################
## a function to smooth piece by piece
########################################
mySmooth <- function(x, idx, fs) {
  nn <- length(x)
  result <- rep(0, nn)
  counter <- 0
  nfs <- length(fs)
  for(i in 1:length(idx)) {
    tmpidx <- counter + (1:idx[i])
    if(idx[i]<nfs)  ## filter long than time series, use average for all
      result[tmpidx] <- mean(x[tmpidx])
    else
      result[tmpidx] <- myfilter(x[tmpidx], fs)
    counter <- counter + idx[i]
  }
  result
}


#######################################################
## calculate probability of a given segment overlap
## with existing sites
#######################################################
prob.overlap <- function(chr, len, d) {
  tmp <- pieces[pieces$chr==chr,]
  ## drop pieces shorter than len+2*d
  ll <- tmp[,3]-tmp[,2]
  idx <- ll>(len+2*d)
  sum(ll[idx])/totlen.chr[chr]
}

prob.overlap2 <- function(obj, d) {
  idx <- split(1:dim(obj)[1], obj$chr)
  ll <- obj$end - obj$start
  res <- rep(NA, dim(obj)[1])
  
  for(i in seq(along=idx)) {
    chr <- names(idx)[i]
    cat(chr, " . ")
    ll.chr <- ll[idx[[chr]]]
    
    tmp <- pieces[pieces$chr==chr,]
    res.chr <- rep(NA, length(idx[[chr]]))
    ll.pieces.chr <- tmp$end - tmp$start

    ll.unique <- unique(ll.chr)
    tbl <- rep(NA, length(ll.unique))
    names(tbl) <- ll.unique
    for(j in seq(along=ll.unique)) {
      ll.tmp <- ll.pieces.chr - (ll.unique[j]+2*d)
      tbl[j] <- 1 - sum(ll.tmp[ll.tmp>0]) /totlen.chr[chr]
    }

    res[idx[[chr]]] <- tbl[as.character(ll.chr)]
  }
  res
}


#######################################################
## pct of closeness
#######################################################
pct.close <- function(cpgs, tss, tag, meth, dd) {
  cat("compare to tss\n")
  cpg.tss <- regionMatch(cpgs, tss)
  idx.tss <- abs(cpg.tss[,1])<=dd

  cat("\ncompare to tag\n")
  cpg.tag <- regionMatch(cpgs, tag)
  idx.tag <- !idx.tss & abs(cpg.tag[,1])<=dd

  cat("\ncompare to DMR\n")
  cpg.meth <- regionMatch(cpgs, meth)
  idx.meth <- !idx.tss & !idx.tag & abs(cpg.meth[,1])<=dd

  a <- c(mean(idx.tss, na.rm=TRUE), mean(idx.tag, na.rm=TRUE),
         mean(idx.meth, na.rm=TRUE))
  a <- c(a, 1-sum(a))
  names(a) <- c("TSS", "TAG", "DMR", "Nothing")
  a
}

## another version of it
pct.close <- function(cpgs, obj, dd) {
  objnames <- names(obj)
  nn <- length(obj)
  idx <- vector("list", nn)

  ## compare
  compare <- vector("list", nn)
  for(i in 1:nn) {
    cat("compare to", objnames[i],  "\n")
    cpg.tss <- regionMatch(cpgs, obj[[i]])
    idx.tss <- abs(cpg.tss[,1])<=dd
  }
}

## a function to collapse data, summing up every K rows
## last several rows will be ignored
collapse.data <- function(dat, K) {
  nn <- nrow(dat)
  n <- floor(nn/K)
  dat2 <-matrix(0, ncol=ncol(dat), nrow=n)
  tmpn <-K*n
  for(i in 1:ncol(dat)) {
    tmp <- matrix(dat[1:tmpn,i],nrow=K)
    dat2[,i] <- colSums(tmp)
  }
  colnames(dat2) <- colnames(dat)
  dat2
}


#####################################################################
## utitlity function to cover a long index to two column of start/end
#####################################################################
idx2mat <- function(idx) {
  dd <- diff(idx)
  ii <- which(dd>1)
  result <- matrix(0, nrow=length(ii)+1, ncol=2)
  result[,1] <- c(1, ii+1)
  result[,2] <- c(ii, length(idx))
  result
}


## a function to take some segment and annotate
## this must run on node 36
annotate <- function(obj, species=c("human","mouse")) {
  species <- match.arg(species)
  if(species=="human")
    require(BSgenome.Hsapiens.UCSC.hg18)
  if(species=="mouse")
    require(BSgenome.Mmusculus.UCSC.mm8)
  
  allidx <- split(1:nrow(obj), obj$chr)
  gcinfo <- matrix(0, nrow=nrow(obj), ncol=4)
  colnames(gcinfo) <- c("CpG", "GCcontent","pctGC", "obsExp")
                        
  for(ichr in 1:length(allidx)) {
    chr <- names(allidx)[ichr]
    cat(chr, ",")
    if(species=="human")
      seq <- Hsapiens[[chr]]
    if(species=="mouse")
      seq <- Mmusculus[[chr]]
    if(length(allidx[[ichr]])==0)
      next
    gcinfo[allidx[[ichr]],] <- add.GCinfo(seq, obj$start[allidx[[ichr]]],
                                          obj$end[allidx[[ichr]]])
  }
  ## conservation score
  tmp <- phastcons(obj, species=species)
  csscore <- tmp[,9]
  ## repeats
  rpscores <- repeatScores(obj, species)

  ## return
  data.frame(obj, gcinfo, csscore=csscore, repeatScore=rpscores)
}

############# a function to get indices in result given location
findLoc <- function(loc, pos.idx,L) {
  a=round(loc/L)
  which(pos.idx==a)
}

## get location distribution of CGI
## cgi.locs is result from matchGenes 
CGI.dist <- function(cgi, cgi.locs) {
  ## 5'
  idx.5p <- cgi.locs$description=="promoter" | cgi.locs$description=="overlaps 5'" |
  cgi.locs$description=="covers"
  ## exon
  tmp <- grep("exon", cgi.locs$description)
  idx.exon <- rep(FALSE,dim(cgi)[1])
  idx.exon[tmp] <- TRUE
  ## tag
  idx.leftover <- which(!(idx.5p|idx.exon))
  cgi.leftover <- cgi[idx.leftover,]
  tmp <- regionMatch(cgi.leftover,tag.no.tss)
  idx.tag <- tmp$type!="disjoint"
  ## intron
  idx.leftover <- idx.leftover[!idx.tag]
  idx.intron <- cgi.locs[idx.leftover,"description"]=="inside intron"
  ## DMR shore
  idx.leftover <- idx.leftover[!idx.intron]
  tmp1 <- regionMatch(cgi[idx.leftover,],dmr)
  idx.dmr <- abs(tmp1$dist)<1000;
  idx.dmr[is.na(idx.dmr)] <- FALSE
  
  result <- c(sum(idx.5p), sum(idx.exon), sum(idx.tag), sum(idx.intron),
              sum(idx.dmr), sum(!idx.dmr))
  names(result) <- c("5'","exon", "unknown TSS", "intron", "DMR", "none")
  result
}

###################################################
## a function to remove the pieces where x>cutoff
###################################################
makelistN <- function(x, cutoff) {
  nn <- length(x)
  flag <- x>cutoff
  if(!any(flag))
    return(NULL)
  startidx <- which(!flag[-nn] & flag[-1])+1
  if(flag[1])
    startidx <- c(1, startidx)
  if(length(startidx)==0)
    next
  endidx <- which(flag[-nn] & !flag[-1])
  if(flag[nn]==1)
    endidx <- c(endidx, nn)
  data.frame(start=startidx, end=endidx)
} 

