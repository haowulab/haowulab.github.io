######################################################
## another function to find CpG. Steps are:
## 1. Remove alu repeat and left over small pieces.
##  Do following for each piece:
## 2. Smooth using Tukey kernel  to get Pc Pg
## 3. Shrink Pc and Pg based on hierarchical model (beta prior)
## 4. HMM with EM
######################################################

####################################################################
## run HMM on number of CpG.
## this function is to work for one chr only
## alu is a matrix of two columns (start, end) for this chr only
####################################################################
findCpG.noalu.engine.CG <- function(dat, repeats, kernel=c("tukey", "rect"), wsize=5,
                                 CG.equal=FALSE, shrink=FALSE, N=8,K=2,
                                 l0, l1, init.prob, trans.prob,
                                 TOL=1e-4, nmaxiter=100) {
  L <- N*K
  kernel <- match.arg(kernel)

  ## collapse data, keep only 4 columns
  if(K>1)
    dat <- collapse.data(dat[,c("C","G","CG","N")],K)
  ## remove alu and N
  res0 <- data.takerpt(dat, repeats[,c("start", "end")], N=L)
  dat0 <- res0$dat; nn <- nrow(dat0)
  ll <-res0$ll
  pos.idx <- res0$pos.idx
  rm(res0); gc()
  
  ## smooth cs and gs - this need to be done in each window
  ## make kernel
  FN <- floor((wsize-1)/2)
  if(kernel=="rect") {
    tmpn <- 2*FN + 1
    fs <- rep(1,tmpn)/tmpn
  }
  else { ## tukey kernel
    Tukey = function(x) pmax(1 - x^2,0)^2
    fs= Tukey(seq(-FN,FN)/(FN+1));fs=fs/sum(fs)
  }
  
  if(CG.equal) { ## assme pc=pg
    Pc <- Pg <- mySmooth(rowSums(dat0[,c("C","G")])/(2*L), ll, fs)
  }
  else { ## use pc and pg separately 
    Pc <- mySmooth(dat0[,"C"]/L, ll, fs)
    Pg <- mySmooth(dat0[,"G"]/L, ll, fs)
  }
  ## shrink cs and gs
  if(shrink) {
    foo.beta <- function(p,n) {
      mp = mean(p);   vp = var(p)
      ## estimate hyperparameters
      tmp = mp*(1-mp)/vp - 1
      a = mp * tmp;  b = (1-mp) * tmp
      x = n*p
      (a+x) / (a+b+n)
    }
    Pc <- foo.beta(Pc, N)
    Pg <- foo.beta(Pg, N)
  }
  
  ## initial values
  if(missing(l1))
    l1 <- 1
  if(missing(l0))
    l0 <- 0.5
  if(missing(init.prob))
    init.prob <- log(c(0.98, 0.02))
  if(missing(trans.prob))
    trans.prob <- log(matrix(c(0.99, 0.01, 0.1, 0.9), 2, byrow=T))
  
  rate <- Pc*Pg*L
  post.prob <- rep(0, nn)
  post.trans.prob <- matrix(0, nrow=nn, ncol=4)
  
  ## EM iteration
  for(iter in 1:nmaxiter) { ## EM iteration
    ## compute emission prob
    emitprob <- matrix(NA, ncol=2, nrow=nn)
    emitprob[,1] <- log(dpois(dat0[,"CG"], l0*rate))
    emitprob[,2] <- log(dpois(dat0[,"CG"], l1*rate))

    ## loop over leftover pieces
    idx <- 0
    for(i in 1:length(ll)) {
      tmpidx <- idx + (1:ll[i])
      if(length(tmpidx)<length(fs)) {
        ## shouldn't come here
        idx <- idx + ll[i]
        next
      }
      ## get posterior probabilities
      tmp1 <- rep(0, ll[i])
      tmp2 <- matrix(0, nrow=ll[i], ncol=4) 
      tmp <- .C("calc_cpg_prob", as.integer(length(tmpidx)),
                as.double(emitprob[tmpidx,]), as.double(init.prob),
                as.double(trans.prob),
                as.integer(1), postprob=as.double(tmp1),
                post.transprob=as.double(tmp2))
      post.prob[tmpidx] <- tmp$postprob
      post.trans.prob[tmpidx,] <- matrix(tmp$post.transprob, ncol=4)
      idx <- idx + ll[i]
    }
    ## update parameters
    ##  init/transition probabilities
    s1 <- sum(post.prob); s0 <- nn - s1
    init.prob.new <- log(c(s0/nn, s1/nn))
    ## be careful in transition probability
    iii <- post.trans.prob[,1]>0
    s1p <- sum(post.prob[iii]); s0p <- sum(iii)-s1
    trans.prob.new <- log(colSums(post.trans.prob[iii,]) / c(s0p, s1p, s0p, s1p))

    ## l0/l1
    l1.new <- sum(post.prob*dat0[,"CG"])/sum(post.prob*rate)
    l0.new <- sum((1-post.prob)*dat0[,"CG"])/sum((1-post.prob)*rate)

    ## check convergency
    dd <- sqrt((l1.new-l1)^2+(l0.new-l0)^2)
    if(dd<TOL | iter==nmaxiter)
      break
    cat("iter ", iter, "l1=", l1.new, ", l0=", l0.new, "\n")
    l1 <- l1.new; l0 <- l0.new
    init.prob <- init.prob.new
    trans.prob <- trans.prob.new
  }
  
  ## return 
  return(invisible(list(postprob=post.prob, pos.idx=pos.idx,
                        l0=l0, l1=l1,
                        transprob=matrix(exp(trans.prob),2),
                        initprob=exp(init.prob))))
}


####################################################################
## run HMM on GC content
## this function is to work for one chr only
## alu is a matrix of two columns (start, end) for this chr only
####################################################################
findCpG.noalu.engine.GCcontent <- function(dat, repeats, kernel=c("tukey", "rect"), wsize=5,
                                           N=8,K=2, mu0, mu1, std,
                                           init.prob, trans.prob,
                                           TOL=1e-4, nmaxiter=100) {
  L <- N*K
  kernel <- match.arg(kernel)

  ## collapse data, keep only 4 columns
  if(K>1)
    dat <- collapse.data(dat[,c("C","G","CG","N")],K)
  ## remove alu and N
  res0 <- data.takerpt(dat, repeats[,c("start", "end")], N=L)
  dat0 <- res0$dat; nn <- nrow(dat0)
  ll <- res0$ll
  pos.idx <- res0$pos.idx
  rm(res0); gc()
  
  ## smooth cs and gs - this need to be done in each window
  ## make kernel
  FN <- floor((wsize-1)/2)
  if(kernel=="rect") {
    tmpn <- 2*FN + 1
    fs <- rep(1,tmpn)/tmpn
  }
  else { ## tukey kernel
    Tukey = function(x) pmax(1 - x^2,0)^2
    fs= Tukey(seq(-FN,FN)/(FN+1));fs=fs/sum(fs)
  }
  ## smooth
  Ngc <- mySmooth(rowSums(dat0[,c("C","G")]), ll, fs)
  
  ## initial values
  if(missing(mu1)) mu1 <- 0.6*L
  if(missing(mu0)) mu0 <- 0.4*L
  if(missing(std)) std <- sd(Ngc)
  if(missing(init.prob))
    init.prob <- log(c(0.98, 0.02))
  if(missing(trans.prob))
    trans.prob <- log(matrix(c(0.99, 0.01, 0.1, 0.9), 2, byrow=T))
  
  post.prob <- rep(0, nn)
  post.trans.prob <- matrix(0, nrow=nn, ncol=4)
  
  ## EM iteration
  for(iter in 1:nmaxiter) { ## EM iteration
    ## compute emission prob
    emitprob <- matrix(NA, ncol=2, nrow=nn)
    emitprob[,1] <- dnorm(Ngc, mean=mu0, sd=std, log=TRUE)
    emitprob[,2] <- dnorm(Ngc, mean=mu1, sd=std, log=TRUE)

    ## loop over leftover pieces
    idx <- 0
    for(i in 1:length(ll)) {
      tmpidx <- idx + (1:ll[i])
      if(length(tmpidx)<length(fs)) {
        ## shouldn't come here
        idx <- idx + ll[i]
        next
      }
      ## get posterior probabilities
      tmp1 <- rep(0, ll[i])
      tmp2 <- matrix(0, nrow=ll[i], ncol=4) 
      tmp <- .C("calc_cpg_prob", as.integer(length(tmpidx)),
                as.double(emitprob[tmpidx,]), as.double(init.prob),
                as.double(trans.prob),
                as.integer(1), postprob=as.double(tmp1),
                post.transprob=as.double(tmp2))
      post.prob[tmpidx] <- tmp$postprob
      post.trans.prob[tmpidx,] <- matrix(tmp$post.transprob, ncol=4)
      idx <- idx + ll[i]
    }
    ## update parameters
    ##  init/transition probabilities
    s1 <- sum(post.prob); s0 <- nn - s1
    init.prob.new <- log(c(s0/nn, s1/nn))
    ## be careful in transition probability
    iii <- post.trans.prob[,1]>0
    s1p <- sum(post.prob[iii]); s0p <- sum(iii)-s1
    trans.prob.new <- log(colSums(post.trans.prob[iii,]) / c(s0p, s1p, s0p, s1p))
    
    ## mu's and std
    mu1.new <- sum(post.prob*Ngc)/sum(post.prob)
    mu0.new <- sum((1-post.prob)*Ngc)/sum((1-post.prob))
    std.new <- mean(post.prob*(Ngc-mu1)^2+(1-post.prob)*(Ngc-mu0)^2)

    ## check convergency
    dd <- sqrt((mu1.new-mu1)^2+(mu0.new-mu0)^2+(std.new-std)^2)
    if(dd<TOL | iter==nmaxiter)
      break
    cat("iter ", iter, "mu1=", mu1.new, ", mu0=", mu0.new, ", std=", std.new, "\n")
    mu1 <- mu1.new; mu0 <- mu0.new; std <- std.new
    init.prob <- init.prob.new
    trans.prob <- trans.prob.new
  }
  
  ## return 
  return(invisible(list(postprob=post.prob, pos.idx=pos.idx,
                        mu0=mu0, mu1=mu1, std=std,
                        transprob=matrix(exp(trans.prob),2),
                        initprob=exp(init.prob))))
}



####################################################################
## run HMM on number of CpG and GC content together.
## this function is to work for one chr only
## alu is a matrix of two columns (start, end) for this chr only
####################################################################
findCpG.noalu.engine.all <- function(dat, repeats, kernel=c("tukey", "rect"), wsize=5,
                                     CG.equal=TRUE, shrink=FALSE, N=8,K=2,
                                     l0, l1, mu0, mu1, std,
                                     init.prob.CpG, trans.prob.CpG,
                                     init.prob.GCcontent, trans.prob.GCcontent,
                                     TOL=1e-4, nmaxiter=100) {
  L <- N*K
  kernel <- match.arg(kernel)

  ## collapse data, keep only 4 columns
  if(K>1)
    dat <- collapse.data(dat[,c("C","G","CG","N")],K)
  ## remove alu and N
  res0 <- data.takerpt(dat, repeats[,c("start", "end")], N=L)
  dat0 <- res0$dat; nn <- nrow(dat0)
  ll <-res0$ll
  pos.idx <- res0$pos.idx
  rm(res0); gc()
  
  ## smooth cs and gs - this need to be done in each window
  ## make kernel
  FN <- floor((wsize-1)/2)
  if(kernel=="rect") {
    tmpn <- 2*FN + 1
    fs <- rep(1,tmpn)/tmpn
  }
  else { ## tukey kernel
    Tukey = function(x) pmax(1 - x^2,0)^2
    fs= Tukey(seq(-FN,FN)/(FN+1));fs=fs/sum(fs)
  }
  
  if(CG.equal) { ## assme pc=pg
    Pc <- Pg <- mySmooth(rowSums(dat0[,c("C","G")])/(2*L), ll, fs)
  }
  else { ## use pc and pg separately 
    Pc <- mySmooth(dat0[,"C"]/L, ll, fs)
    Pg <- mySmooth(dat0[,"G"]/L, ll, fs)
  }
  ## GC content
  Ngc <- (Pc+Pg)*L ## smoothed
  ##Ngc0 <- rowSums(dat0[,c("C","G")])
  
  ## shrink cs and gs
  if(shrink) {
    foo.beta <- function(p,n) {
      mp = mean(p);   vp = var(p)
      ## estimate hyperparameters
      tmp = mp*(1-mp)/vp - 1
      a = mp * tmp;  b = (1-mp) * tmp
      x = n*p
      (a+x) / (a+b+n)
    }
    Pc <- foo.beta(Pc, N)
    Pg <- foo.beta(Pg, N)
  }
  
  ## initial values
  if(missing(l1))     l1 <- 0.7
  if(missing(l0))    l0 <- 0.6
  if(missing(mu1)) mu1 <- 0.6*L
  if(missing(mu0)) mu0 <- 0.4*L
  if(missing(std)) std <- sd(Ngc)
  if(missing(init.prob.CpG))    init.prob.CpG <- log(c(0.98, 0.02))
  if(missing(trans.prob.CpG))  trans.prob.CpG <- log(matrix(c(0.99, 0.01, 0.1, 0.9), 2, byrow=T))
  if(missing(init.prob.GCcontent))    init.prob.GCcontent <- log(c(0.98, 0.02))
  if(missing(trans.prob.GCcontent))
    trans.prob.GCcontent <- log(matrix(c(0.99, 0.01, 0.1, 0.9), 2, byrow=T))
  
  
  rate <- Pc*Pg*L
  post.prob <- rep(0, nn)
  post.trans.prob <- matrix(0, nrow=nn, ncol=4)
  
  ## EM iteration for CpG
  cat("HMM for CpG:\n")
  for(iter in 1:nmaxiter) { ## EM iteration
    ## compute emission prob
    emitprob <- matrix(NA, ncol=2, nrow=nn)
    emitprob[,1] <- dpois(dat0[,"CG"], l0*rate, log=TRUE)
    emitprob[,2] <- dpois(dat0[,"CG"], l1*rate, log=TRUE)

    ## loop over leftover pieces
    idx <- 0
    for(i in 1:length(ll)) {
      tmpidx <- idx + (1:ll[i])
      if(length(tmpidx)<length(fs)) {
        ## shouldn't come here
        idx <- idx + ll[i]
        next
      }
      ## get posterior probabilities
      tmp1 <- rep(0, ll[i])
      tmp2 <- matrix(0, nrow=ll[i], ncol=4) 
      tmp <- .C("calc_cpg_prob", as.integer(length(tmpidx)),
                as.double(emitprob[tmpidx,]), as.double(init.prob.CpG),
                as.double(trans.prob.CpG),
                as.integer(1), postprob=as.double(tmp1),
                post.transprob=as.double(tmp2))
      post.prob[tmpidx] <- tmp$postprob
      post.trans.prob[tmpidx,] <- matrix(tmp$post.transprob, ncol=4)
      idx <- idx + ll[i]
    }
    ## update parameters
    ##  init/transition probabilities
    s1 <- sum(post.prob); s0 <- nn - s1
    init.prob.new <- log(c(s0/nn, s1/nn))
    ## be careful in transition probability
    iii <- post.trans.prob[,1]>0
    s1p <- sum(post.prob[iii]); s0p <- sum(iii)-s1p
    trans.prob.new <- log(colSums(post.trans.prob[iii,]) / c(s0p, s1p, s0p, s1p))
    ## l0/l1
    l1.new <- sum(post.prob*dat0[,"CG"])/sum(post.prob*rate)
    l0.new <- sum((1-post.prob)*dat0[,"CG"])/sum((1-post.prob)*rate)

    ## check convergency
    dd <- sqrt((l1.new-l1)^2+(l0.new-l0)^2)
    if(dd<TOL | iter==nmaxiter)
      break
    cat("iter ", iter, "l1=", l1.new, ", l0=", l0.new, "\n")
    l1 <- l1.new; l0 <- l0.new
    init.prob.CpG <- init.prob.new
    trans.prob.CpG <- trans.prob.new
  }

  post.prob.CpG <- post.prob
  gc()
  
#browser()
  ## now run HMM for GC content
  cat("HMM for GC content:\n")
  post.prob <- rep(0, nn)
  post.trans.prob <- matrix(0, nrow=nn, ncol=4)
  
  ## EM iteration
  for(iter in 1:nmaxiter) { ## EM iteration
    ## compute emission prob
    emitprob <- matrix(NA, ncol=2, nrow=nn)
    emitprob[,1] <- dnorm(Ngc, mean=mu0, sd=std, log=TRUE)
    emitprob[,2] <- dnorm(Ngc, mean=mu1, sd=std, log=TRUE)
    
    ## loop over leftover pieces
    idx <- 0
    for(i in 1:length(ll)) {
      tmpidx <- idx + (1:ll[i])
      if(length(tmpidx)<length(fs)) {
        ## shouldn't come here
        idx <- idx + ll[i]
        next
      }
      ## get posterior probabilities
      tmp1 <- rep(0, ll[i])
      tmp2 <- matrix(0, nrow=ll[i], ncol=4)
      tmp <- .C("calc_cpg_prob", as.integer(length(tmpidx)),
                as.double(emitprob[tmpidx,]), as.double(init.prob.GCcontent),
                as.double(trans.prob.GCcontent),
                as.integer(1), postprob=as.double(tmp1),
                post.transprob=as.double(tmp2))
      post.prob[tmpidx] <- tmp$postprob
      post.trans.prob[tmpidx,] <- matrix(tmp$post.transprob, ncol=4)
      idx <- idx + ll[i]
    }
    ## update parameters
    ##  init/transition probabilities
    s1 <- sum(post.prob); s0 <- nn - s1
    init.prob.new <- log(c(s0/nn, s1/nn))
    ## be careful in transition probability
    iii <- post.trans.prob[,1]>0
    s1p <- sum(post.prob[iii]); s0p <- sum(iii)-s1
    trans.prob.new <- log(colSums(post.trans.prob[iii,]) / c(s0p, s1p, s0p, s1p))
    
    ## mu's and std
    mu1.new <- sum(post.prob*Ngc)/sum(post.prob)
    mu0.new <- sum((1-post.prob)*Ngc)/sum((1-post.prob))
    std.new <- mean(post.prob*(Ngc-mu1)^2+(1-post.prob)*(Ngc-mu0)^2)
    
    ## check convergency
    dd <- sqrt((mu1.new-mu1)^2+(mu0.new-mu0)^2+(std.new-std)^2)
    if(dd<TOL | iter==nmaxiter)
      break
    cat("iter ", iter, "mu1=", mu1.new, ", mu0=", mu0.new, ", std=", std.new, "\n")
    mu1 <- mu1.new; mu0 <- mu0.new; std <- std.new
    init.prob.GCcontent <- init.prob.new
    trans.prob.GCcontent <- trans.prob.new
  }
  
  ## return 
  return(invisible(list(postprob.CpG=post.prob.CpG,
                        postprob.GCcontent=post.prob,
                        pos.idx=pos.idx,
                        l0=l0, l1=l1,mu0=mu0, mu1=mu1, std=std,
                        transprob.CpG=matrix(exp(trans.prob.CpG),2),
                        initprob.CpG=exp(init.prob.CpG),
                        transprob.GCcontent=matrix(exp(trans.prob.GCcontent),2),
                        initprob.GCcontent=exp(init.prob.GCcontent))))
}


