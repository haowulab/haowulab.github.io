phastcons <- function(object,c=-1,species="human"){
  write.table(data.frame(object$chr,object$start,object$end,rep("+",nrow(object))),file="tmp.cod",sep="\t",quote=FALSE,col.names=FALSE)
  if(species=="human") thecall=paste("~hji/projects/cisgenome_project/bin/genome_regioncssummary -gd /data1/hji/data/genomes/human/hg18 -i tmp.cod -o tmp.txt -c",c,"-cd /data1/hji/data/genomes/human/hg18/conservation/phastcons/")
  if(species=="mouse") thecall=paste("~hji/projects/cisgenome_project/bin/genome_regioncssummary -gd /data1/hji/data/genomes/mouse/mm8 -i tmp.cod -o tmp.txt -c",c,"-cd /data1/hji/data/genomes/mouse/mm8/conservation/phastcons/")
  system(thecall)
  res=read.delim("tmp.txt",as.is=TRUE,check.names=FALSE)
  res
}  

neighborgenes <- function(object,g=5000,up=1,down=1,species="human"){
  write.table(data.frame(object$chr,object$start,object$end,rep("+",nrow(object))),file="tmp.cod",sep="\t",quote=FALSE,col.names=FALSE)
  if(species=="human") thecall=paste("~hji/projects/cisgenome_project/bin/reflocus_getneighborgenes -d /data1/hji/data/genomes/human/hg18/annotation/refLocus_sorted.txt -s human -i tmp.cod -o tmp.txt -g",g,"-up",up,"-down",down)
  if(species=="mouse") thecall=paste("~hji/projects/cisgenome_project/bin/reflocus_getneighborgenes -d /data1/hji/data/genomes/mouse/mm8/annotation/refLocus_sorted.txt -s mouse -i tmp.cod -o tmp.txt -g",g,"-up",up,"-down",down)

  system(thecall)
  res=read.delim("tmp.txt",as.is=TRUE,check.names=FALSE, na.string=c("---", "?"))
  res
}

nearestgene <- function(object,up=5000,down=5000,species="human"){
  tmpscipen=.Options$scipen
  options(scipen=100)
  write.table(data.frame(object$chr,object$start,object$end,rep("+",nrow(object))),file="tmp.cod",sep="\t",quote=FALSE,col.names=FALSE)
  if(species=="human") thecall=paste("~hji/projects/cisgenome_project/bin/refgene_getnearestgene  -d /data1/hji/data/genomes/human/hg18/annotation/refFlat_sorted.txt -dt 1 -s human -i tmp.cod -o tmp.txt -r 0 -up",up,"-down",down)
  if(species=="mouse") thecall=paste("~hji/projects/cisgenome_project/bin/refgene_getnearestgene  -d /data1/hji/data/genomes/mouse/mm8/annotation/refFlat_sorted.txt -dt 1 -s mouse -i tmp.cod -o tmp.txt -r 0 -up",up,"-down",down)
  system(thecall)
  res=read.delim("tmp.txt",as.is=TRUE,check.names=FALSE,comment.char="#",header=FALSE,col.names=c("seq_id","chr","start","end","strand","name","annotation","num","genestrand","TSS","TSE","CSS","CSE","ne","exonStarts","exonEnds"),fill=NA)
  res[res=="---"]<-NA
  res[res==""] <- NA
  options(scipen=tmpscipen)
  res
}


motif <- function(object,motifNumber=3,meanMotifLength=12,maxMotifLength=30,mcmcIterations=5000,fastaFile=NULL,verbose=TRUE){

  if(is.null(fastaFile)){
    fastaFile="tmp.fa"
    sequenceFasta(object,filename=fastaFile)
  }
  if(verbose) cat("\nLooking for motifs\n")
  cat("[Working Directory] = .\n",file="tmp.txt")
  cat("[FASTA Sequence] = ",fastaFile,"\n",file="tmp.txt",append=TRUE)
  cat("[Output File] = tmp_motif\n",file="tmp.txt",append=TRUE)
  cat("[Use *.cs?] (0:No; 1:Yes) = 0\n",file="tmp.txt",append=TRUE)
  cat("[CS Prefix] = NULL\n",file="tmp.txt",append=TRUE)
  cat("[CS Likelihood f] = cslike.txt\n",file="tmp.txt",append=TRUE)
  cat("[Motif Number K] =",motifNumber,"\n",file="tmp.txt",append=TRUE)
  cat("[Mean Motif Length Lamda] =",meanMotifLength,"\n",file="tmp.txt",append=TRUE)
  cat("[Maximal Motif Length Allowed] =",maxMotifLength,"\n",file="tmp.txt",append=TRUE)
  cat("[Init Motif Length L] =",
      paste(rep(meanMotifLength,motifNumber),collapse=","),"\n",
            file="tmp.txt",append=TRUE)
  cat("[Init Motif Matrix]\n",file="tmp.txt",append=TRUE)
  for(i in 1:motifNumber)
    cat("NULL\n",file="tmp.txt",append=TRUE)
  cat("[Init Motif Abundance] = priorabundance.txt\n",file="tmp.txt",append=TRUE)
  cat("[Init Module Size D] = 2.0\n",file="tmp.txt",append=TRUE)
  cat("[Module Length] = 150\n",file="tmp.txt",append=TRUE)
  cat("[Sample Module Length?] (0:No; 1:Yes) = 0\n",file="tmp.txt",append=TRUE)
  cat("[Order of Background Markov Chain] = 3\n",file="tmp.txt",append=TRUE)
  cat("[Use Fitted Background?] (0:No; 1:Yes) = 0\n",file="tmp.txt",append=TRUE)
  cat("[Fitted Background Prefix] = NULL\n",file="tmp.txt",append=TRUE)
  cat("[MCMC Iteration] = ",mcmcIterations,"\n",file="tmp.txt",append=TRUE)

  tmp=matrix(c(1000,0,rep(2,motifNumber*2)),ncol=2,byrow=TRUE)
  write.table(tmp,file="priorabundance.txt",quote=FALSE,row.names=FALSE,col.names=FALSE,sep="\t")
  system("~hji/projects/cisgenome_project/bin/flexmodule_motif tmp.txt")
}


readMotif <- function(file="tmp_motif",N=12,plot=TRUE){
  require(seqLogo)
  res=vector("list",N)
  for(i in 0:(N-1)){
    fns=paste(file,"_",i,".mat",sep="")
    x=t(matrix(scan(fns),ncol=4,byrow=TRUE))
    x=sweep(x,2,colSums(x),"/")
    res[[i+1]]= makePWM(x)
    if(plot){
      seqLogo(res[[i+1]])
    }
  }
  return(res)
}

## filter repeated region
filterRepeats <- function(object, r=0.5, species="human") {
  tmp <- as.matrix(data.frame(object$chr,object$start,object$end,rep("+",nrow(object))))
  write.table(tmp, file="tmp.txt",sep="\t",quote=FALSE,col.names=FALSE)
  if(species=="human") thecall=paste("genome_getseq_c -d /data1/hji/data/genomes/human/hg18 -i tmp.txt -o result.txt  -s human")
  if(species=="mouse") thecall=paste("genome_getseq_c -d /data1/hji/data/genomes/human/hg18 -i tmp.txt -o result.txt  -s mouse")    
  system(thecall)
  res=read.delim("result.txt",as.is=TRUE,check.names=FALSE, header=F)
  res
}

## get repeat scores - 
## I need to revisit it some time
repeatScores <- function(obj, species=c("human","mouse","fly")) {
  species <- match.arg(species)
  if(species=="human") thecall=paste("~/cisgenome/bin/getRepeats -d /data1/hji/data/genomes/human/hg18 -i tmp.txt -o result.txt  -s human")
  if(species=="mouse") thecall=paste("~/cisgenome/bin/getRepeats -d /data1/hji/data/genomes/mouse/mm8 -i tmp.txt -o result.txt  -s mouse")
  if(species=="fly") thecall=paste("~/cisgenome/bin/getRepeats -d /data1/hji/data/genomes/fly -i tmp.txt -o result.txt  -s fly")
  
  n <- nrow(obj)
  scores <- rep(NA, n)
  ## write to file
  tmp <- as.matrix(data.frame(obj$chr,obj$start,obj$end,rep("+",nrow(obj))))
  write.table(tmp, file="tmp.txt",sep="\t",quote=FALSE,col.names=FALSE)
  system(thecall)
  ## read results
  res <- as.matrix(read.table("result.txt"))
  res[res==99] <- NA
  as.vector(res)
}

## get motif
## motifmap_consensusscan_genome -m 
getmotif <- function(object, species=c("mouse", "human"), mc=2) {
  species=match.arg(species)
  if(species=="human")
    thecall=paste("motifmap_consensusscan_genome -m motif.txt -gd /data1/hji/data/genomes/human/hg18",
      "-i tmp.txt -o result.txt -mc", mc,  " -md 1")
  if(species=="mouse")
    thecall=paste("motifmap_consensusscan_genome -m motif.txt -gd /data1/hji/data/genomes/mouse/mm8",
      "-i tmp.txt -o result.txt -mc", mc, "-md 1")
  
  ## write out coordinates
  tmp <- as.matrix(data.frame(object$chr,object$start,object$end,rep("+",nrow(object))))
  write.table(tmp, file="tmp.txt",sep="\t",quote=FALSE,col.names=FALSE)
  system(thecall)

  ## grab output
  a <- try(res <- read.table("result.txt", sep="\t")[,-1], TRUE)
  if(class(a) == "try-error")
    res <- NULL
  else 
    colnames(res) <- c("chr", "start", "end", "strand", "score", "site")
  res
}

## get motif
## motifmap_consensusscan_genome -m 
getmotif.matrix <- function(object, species=c("mouse", "human"), lr=1000) {
  species=match.arg(species)
  if(species=="human")
    thecall=paste("motifmap_matrixscan_genome -m gli-matrix.txt -gd /data1/hji/data/genomes/human/hg18",
      "-i tmp.txt -o result.txt -r", lr, "-b 3 -bt genome -bs 100000",
      "-bd /data1/hji/data/genomes/human/hg18/markovbg/S100000_W1000000/")
  if(species=="mouse")
    thecall=paste("motifmap_matrixscan_genome -m gli-matrix.txt -gd /data1/hji/data/genomes/mouse/mm8",
      "-i tmp.txt -o result.txt -r", lr, "-b 3 -bt genome -bs 100000",
      "-bd /data1/hji/data/genomes/human/hg18/markovbg/S100000_W1000000/")

  ## write out coordinates
  tmp <- as.matrix(data.frame(object$chr,object$start,object$end,rep("+",nrow(object))))
  write.table(tmp, file="tmp.txt",sep="\t",quote=FALSE,col.names=FALSE)
  system(thecall)

  ## grab output
  res <- read.table("result.txt", sep="\t")[,-1]
  colnames(res) <- c("chr", "start", "end", "strand", "score", "site")
  res
}



###CISGENOME NOTES, data /data1/hji/data/genomes/human/hg18
##conservation score, 

###~hji/projects/cisgenome_project/bin/genome_regioncssummary -gd /data1/hji/data/genomes/human/hg18 -i ~/projects/cegs/where-is-methylation/tmp.cod -o tmp.txt -c -1 -cd /data1/hji/data/genomes/human/hg18/conservation/phastcons/

##~hji/projects/cisgenome_project/bin/refgene_getnearestgene  -d /data1/hji/data/genomes/human/hg18/annotation/refFlat_sorted.txt -dt 1 -s human -i ~/projects/cegs/where-is-methylation/tmp.cod -o tmp.txt -r 0 -up 5000 -down 1000
##reports: number of exons, start and end

##~hji/projects/cisgenome_project/bin/reflocus_getneighborgenes -d /data1/hji/data/genomes/human/hg18/annotation/refLocus_sorted.txt -s human -i ~/projects/cegs/where-is-methylation/tmp.cod -o tmp.txt -g 100000 -up 3 -down 3 
