### function to get aggregated parameters
getAllParam.GCcontent <- function(.CGIoptions) {
  ## init
  totaln <- 0
  mu0 <- mu1 <- std <- 0
  initprob <- rep(0,2)
  transprob <- matrix(0, 2,2)

  ## forward-backward files
  files=dir(.CGIoptions$tmpDir, patter="^param.GCcontent")
  nfiles <- length(files)
  all.mu0 <- all.mu1 <- all.std <- rep(0, nfiles)
  all.initprob  <- matrix(0, nrow=2, ncol=nfiles)
  all.transprob <- array(0, dim=c(2,2,nfiles))
  all.n <- rep(0, nfiles)

  ## loop on result files
  for(i in seq(along=files)) {
    load(paste(.CGIoptions$tmpDir, "/", files[i], sep=""))
    all.n[i] <- param$n
    all.mu0[i] <- param$mu0
    all.mu1[i] <- param$mu1
    all.std[i] <- param$std
    all.initprob[,i] <- param$initprob
    all.transprob[,,i] <- param$transprob
  }

  ## average across chromosomes
  mu0 <- sum(all.mu0*all.n) / sum(all.n)
  mu1 <- sum(all.mu1*all.n) / sum(all.n)
  std <- sum(all.std*all.n)/sum(all.n)
  
  ## init prob
  for(i in 1:2) {
    initprob[i] <- sum(all.initprob[i,]*all.n) / sum(all.n)
  }
  ## trans prob
  for(i in 1:length(all.n)) {
    ## cpg
    transprob <- transprob + all.transprob[,,i]*all.n[i]
  }
  transprob <- transprob / sum(all.n)

  param <- list(mu0=mu0, mu1=mu1, std=std, initprob=initprob, transprob=transprob)
  
  ## save
  save(param,file=paste(.CGIoptions$resultDir,"/allparam-GCcontent.rda",sep=""))
  param
}

#####################################################
## get parameters for CpG
#####################################################
getAllParam.CpG <- function(.CGIoptions) {
  ## init
  totaln <- 0
  l0 <- l1 <- 0
  initprob <- rep(0,2)
  transprob <- matrix(0, 2,2)

  ## forward-backward files
  files=dir(.CGIoptions$tmpDir, patter="^param.CpG")
  nfiles <- length(files)
  all.l0 <- all.l1 <- rep(0, nfiles)
  all.initprob  <- matrix(0, nrow=2, ncol=nfiles)
  all.transprob <- array(0, dim=c(2,2,nfiles))
  all.n <- rep(0, nfiles)

  ## loop on result files
  for(i in seq(along=files)) {
    load(paste(.CGIoptions$tmpDir, "/", files[i], sep=""))
    all.n[i] <- param$n
    all.l0[i] <- param$l0
    all.l1[i] <- param$l1
    all.initprob[,i] <- param$initprob
    all.transprob[,,i] <- param$transprob
  }

  ## average across chromosomes
  l0 <- sum(all.l0*all.n) / sum(all.n)
  l1 <- sum(all.l1*all.n) / sum(all.n)
  
  ## init prob
  for(i in 1:2) {
    initprob[i] <- sum(all.initprob[i,]*all.n) / sum(all.n)
  }
  ## trans prob
  for(i in 1:length(all.n)) {
    ## cpg
    transprob <- transprob + all.transprob[,,i]*all.n[i]
  }
  transprob <- transprob / sum(all.n)

  param <- list(l0=l0, l1=l1, initprob=initprob, transprob=transprob)
  
  ## save
  save(param,file=paste(.CGIoptions$resultDir,"/allparam-CpG.rda",sep=""))
  param
}
