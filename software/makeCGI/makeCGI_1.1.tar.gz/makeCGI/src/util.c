/* some utility functions */
#include <math.h>
#include <stdlib.h>
#include <stdio.h>
#include <R.h>
#include <Rmath.h>
#include <R_ext/PrtUtil.h>
#include <Rinternals.h>
#include <Rdefines.h>
#include <R_ext/RConverters.h>
#include <R_ext/Rdynload.h>
            

/* a function to look for overlap between a vector and a matrix*.
   the rows of matrix should be sorted */

void overlap(double *v_ptr, double *mat_ptr, int *n, int *res) {
  int i, k, idx, start, end, nrow; 
  nrow = *n;
  start = 0; 
  end = nrow-1;
  /* binary search */
  while(end > start) {
    idx = (int)(start+end)/2; 
    if(v_ptr[1]<=mat_ptr[idx]) { /* should move up */
      end = idx;
    }
    else if(v_ptr[0]>=mat_ptr[idx+nrow]) { /* should move down */
      start = idx;
    }
    else {/* right here */
      res[0] = idx + 1;
      break;
    }
    if(end==start+1) /* in middle of two intervals */
      break;
  }
  k = 1;
  /* there could be multiple matches, find all of them */ 
  /* search up */
  for(i=idx-1; i>=0; i--) {
    if(v_ptr[1]>=mat_ptr[i] & v_ptr[0]<=mat_ptr[i+nrow]) {
      res[k] = i+1; 
      k = k + 1;
    }
    if(v_ptr[0]>mat_ptr[i+nrow])
      break;
  }
  /* search down*/ 
  for(i=idx+1; i<nrow; i++) {
    if(v_ptr[1]>=mat_ptr[i] & v_ptr[0]<=mat_ptr[i+nrow]) {
      res[k] = i+1;
      k = k+1;
    }
    if(v_ptr[0]>mat_ptr[i+nrow])
      break;
  }
  /*  return(result); */
}
