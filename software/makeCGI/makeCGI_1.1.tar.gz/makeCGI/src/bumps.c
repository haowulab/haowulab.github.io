/* function to find bumps, R caller is:
   ii <- .Call("findBumps", pos[idx[[ichr]]], x[idx[[ichr]]], cutoff, as.integer(minlen),
               as.integer(mincount), dis.merge, as.integer(trim))
*/

#include <R.h>
#include <Rmath.h>
#include <R_ext/PrtUtil.h>
#include <Rinternals.h>
#include <Rdefines.h>
#include <R_ext/RConverters.h>
#include <R_ext/Rdynload.h>

SEXP findBumps(SEXP R_pos, SEXP R_x, SEXP R_cutoff, SEXP R_sep,
               SEXP R_minlen, SEXP R_mincount, SEXP R_dmerge);

SEXP findBumps(SEXP R_pos, SEXP R_x, SEXP R_cutoff, SEXP R_sep,
	       SEXP R_minlen, SEXP R_mincount, SEXP R_dmerge) {
  int i, ipos, n0=100000, bumpflag, inbump; 
  int *tmpidx, *tmpidx2, counter=0, counter2=0;
  double tmplen;
  int nobs=length(R_x);
  int *pos=INTEGER(R_pos);
  double *x=REAL(R_x);
  double cutoff=*REAL(R_cutoff);
  double sep=*REAL(R_sep);
  double minlen=*REAL(R_minlen);
  int mincount=*INTEGER(R_mincount);
  double dmerge= *REAL(R_dmerge);

  tmpidx=tmpidx2=(int *) R_alloc(n0, sizeof(int));

  /* scan the vector to get start/end positions */
  bumpflag = x[0]>cutoff;
  if(bumpflag) {
    inbump = 1;
    tmpidx[0]=0;
  }
  
  for(ipos=1; ipos<nobs; ipos++) {
    bumpflag=x[ipos]>cutoff;
    if(inbump) {     /* if there's open bump */
      if( (pos[ipos]-pos[ipos-1])>sep | bumpflag==0 ) {
	/* either hit the end of region or down edge, need to close this bump */
	inbump = 0;
	tmpidx[2*counter+1]=ipos-1;
	counter ++;
      }
    } 
    else {  /* not in bump region */
      if(bumpflag) {
	inbump = bumpflag;
	tmpidx[2*counter]=ipos;
      }
    }
  }
  /* careful at the end of chain */
  if(inbump) { /* need to close the bump */
    tmpidx[2*counter+1]=nobs-1;
    counter ++;
  }

  if(counter==0) { /* no bump */
    return(allocVector(NILSXP, 1));
  }

  /* finished scanning, now merge close bumps */  
  tmpidx2[0]=tmpidx[0];
  counter2 = 0;
  for(i=1; i<counter; i++) {
    if(pos[tmpidx[i*2]]-pos[tmpidx[i*2-1]]>dmerge) { /* don't need to merge */
      tmpidx2[counter2*2+1] = tmpidx[i*2-1];
      counter2 ++;
      /* start index for next bump */
      tmpidx2[counter2*2] = tmpidx[i*2];
    }
  }
  tmpidx2[counter2*2+1] = tmpidx[2*counter-1]; /* the last one */
  counter2 ++;

  /* finish merging, keep those bumps long enough */
  counter = 0;
  for(i=0; i<counter2; i++) {
    tmplen=pos[tmpidx2[i*2+1]]-pos[tmpidx2[i*2]];
    if(tmplen>minlen & (tmpidx2[i*2+1]-tmpidx2[i*2])>mincount) {
      tmpidx[counter*2] = tmpidx2[i*2];
      tmpidx[counter*2+1] = tmpidx2[i*2+1];
      counter ++;
    }
  }
  if(counter==0) { /* nothing left */
    return(allocVector(NILSXP, 1));
  }
  /* return */
  SEXP res;
  PROTECT(res = allocVector(INTSXP, counter*2));
  memcpy(INTEGER(res), tmpidx, counter*2*sizeof(int));
  UNPROTECT(1);
  return(res);
}

