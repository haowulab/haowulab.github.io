######################################################
## engine functions of HMM.
######################################################

####################################################################
## run HMM on number of CpG.
## this function is to work for one chr only
## alu is a matrix of two columns (start, end) for this chr only
####################################################################
HMM.engine.CpG <- function(Ncpg, Pc, ll, L, l0, l1, init.prob, trans.prob,
                           TOL=1e-4, nmaxiter=50, verbose=FALSE) {
  nn <- length(Ncpg)
  ## initial values
  if(missing(l1))
    l1 <- 1
  if(missing(l0))
    l0 <- 0.5
  if(missing(init.prob))
    init.prob <- log(c(0.98, 0.02))
  if(missing(trans.prob))
    trans.prob <- log(matrix(c(0.99, 0.01, 0.1, 0.9), 2, byrow=T))

  rate <- Pc^2*L
  post.prob <- rep(0, nn)
  post.trans.prob <- matrix(0, nrow=nn, ncol=4)
  
  ## EM iteration
  for(iter in 1:nmaxiter) { ## EM iteration
    ## compute emission prob
    emitprob <- matrix(NA, ncol=2, nrow=nn)
    emitprob[,1] <- log(dpois(Ncpg, l0*rate))
    emitprob[,2] <- log(dpois(Ncpg, l1*rate))
    ## loop over leftover pieces
    idx <- 0
    for(i in 1:length(ll)) {
      tmpidx <- idx + (1:ll[i])
      if(length(tmpidx)<3) {
        ## shouldn't come here
        idx <- idx + ll[i]
        next
      }
      ## get posterior probabilities
      tmp1 <- rep(0, ll[i])
      tmp2 <- matrix(0, nrow=ll[i], ncol=4)
      tmp <- .C("calc_cpg_prob", as.integer(length(tmpidx)),
                as.double(emitprob[tmpidx,]), as.double(init.prob),
                as.double(trans.prob),
                as.integer(1), postprob=as.double(tmp1),
                post.transprob=as.double(tmp2))
      post.prob[tmpidx] <- tmp$postprob
      post.trans.prob[tmpidx,] <- matrix(tmp$post.transprob, ncol=4)
      idx <- idx + ll[i]
    }
    ## update parameters
    ##  init/transition probabilities
    s1 <- sum(post.prob); s0 <- nn - s1
    init.prob.new <- log(c(s0/nn, s1/nn))
    ## be careful in transition probability
    iii <- post.trans.prob[,1]>0
    s1p <- sum(post.prob[iii]); s0p <- sum(iii)-s1
    trans.prob.new <- log(colSums(post.trans.prob[iii,]) / c(s0p, s1p, s0p, s1p))

    ## l0/l1
    l1.new <- sum(post.prob*Ncpg)/sum(post.prob*rate)
    l0.new <- sum((1-post.prob)*Ncpg)/sum((1-post.prob)*rate)

    ## check convergency
    dd <- sqrt((l1.new-l1)^2+(l0.new-l0)^2)
    if(dd<TOL | iter==nmaxiter)
      break
    if(verbose)
      cat("iter ", iter, "l1=", l1.new, ", l0=", l0.new, "\n")
    l1 <- l1.new; l0 <- l0.new
    init.prob <- init.prob.new
    trans.prob <- trans.prob.new
  }
  
  ## return 
  return(invisible(list(postprob=post.prob, l0=l0, l1=l1,
                        transprob=matrix(exp(trans.prob),2),
                        initprob=exp(init.prob))))
}


####################################################################
## run HMM on GC content
## this function is to work for one chr only
####################################################################
HMM.engine.GCcontent <- function(Ngc, ll, L, mu0, mu1, std, init.prob, trans.prob,
                                 TOL=1e-4, nmaxiter=100, verbose=TRUE) {
  ## initial values
  if(missing(mu1)) mu1 <- 0.6*L
  if(missing(mu0)) mu0 <- 0.4*L
  if(missing(std)) std <- sd(Ngc)
  if(missing(init.prob))
    init.prob <- log(c(0.98, 0.02))
  if(missing(trans.prob))
    trans.prob <- log(matrix(c(0.99, 0.01, 0.1, 0.9), 2, byrow=T))
  nn <- length(Ngc)
  post.prob <- rep(0, nn)
  post.trans.prob <- matrix(0, nrow=nn, ncol=4)

  ## EM iteration
  for(iter in 1:nmaxiter) { ## EM iteration
    ## compute emission prob
    emitprob <- matrix(NA, ncol=2, nrow=nn)
    emitprob[,1] <- dnorm(Ngc, mean=mu0, sd=std, log=TRUE)
    emitprob[,2] <- dnorm(Ngc, mean=mu1, sd=std, log=TRUE)

    ## loop over leftover pieces
    idx <- 0
    for(i in 1:length(ll)) {
      tmpidx <- idx + (1:ll[i])
      if(length(tmpidx)<3) {
        ## shouldn't come here
        idx <- idx + ll[i]
        next
      }
      ## get posterior probabilities
      tmp1 <- rep(0, ll[i])
      tmp2 <- matrix(0, nrow=ll[i], ncol=4) 
      tmp <- .C("calc_cpg_prob", as.integer(length(tmpidx)),
                as.double(emitprob[tmpidx,]), as.double(init.prob),
                as.double(trans.prob),
                as.integer(1), postprob=as.double(tmp1),
                post.transprob=as.double(tmp2))
      post.prob[tmpidx] <- tmp$postprob
      post.trans.prob[tmpidx,] <- matrix(tmp$post.transprob, ncol=4)
      idx <- idx + ll[i]
    }
    ## update parameters
    ##  init/transition probabilities
    s1 <- sum(post.prob); s0 <- nn - s1
    init.prob.new <- log(c(s0/nn, s1/nn))
    ## be careful in transition probability
    iii <- post.trans.prob[,1]>0
    s1p <- sum(post.prob[iii]); s0p <- sum(iii)-s1
    trans.prob.new <- log(colSums(post.trans.prob[iii,]) / c(s0p, s1p, s0p, s1p))
    
    ## mu's and std
    mu1.new <- sum(post.prob*Ngc)/sum(post.prob)
    mu0.new <- sum((1-post.prob)*Ngc)/sum((1-post.prob))
    std.new <- sqrt(mean(post.prob*(Ngc-mu1)^2+(1-post.prob)*(Ngc-mu0)^2))

    ## check convergency
    dd <- sqrt((mu1.new-mu1)^2+(mu0.new-mu0)^2+(std.new-std)^2)
    if(dd<TOL | iter==nmaxiter)
      break
    if(verbose)
      cat("iter ", iter, "mu1=", mu1.new, ", mu0=", mu0.new, ", std=", std.new, "\n")
    mu1 <- mu1.new; mu0 <- mu0.new; std <- std.new
    init.prob <- init.prob.new
    trans.prob <- trans.prob.new
  }
  
  ## return 
  return(invisible(list(postprob=post.prob,
                        mu0=mu0, mu1=mu1, std=std,
                        transprob=matrix(exp(trans.prob),2),
                        initprob=exp(init.prob))))
}



