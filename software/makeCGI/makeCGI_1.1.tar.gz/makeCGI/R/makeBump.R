
makeBumps <- function(chr, pos, x, cutoff, sep=2000,
                      minlen=100, minCount=3, dis.merge=100, index.return=FALSE) {
  flag <- as.numeric(x>cutoff)
  flag[is.na(flag)]=FALSE 
  ## loop on regions
  initn <- 20000
  bumps <- data.frame(chr=rep("chr1",initn), start=rep(0,initn),
                       end=rep(0, initn), length=rep(0, initn))
  if(index.return)
    res.idx <- matrix(0, nrow=initn, ncol=2)
  levels(bumps[,1]) <- unique(chr)

  counter <- 0
  idx <- split(1:length(chr), chr)
  for(ichr in seq(along=idx)) {
    thispos=pos[idx[[ichr]]]
    tmp <- .Call("findBumps", as.integer(thispos), x[idx[[ichr]]], as.double(cutoff), as.double(sep),
                as.double(minlen), as.integer(minCount), as.double(dis.merge))
    if(is.null(tmp))
      next
    tmp=matrix(tmp, byrow=TRUE, ncol=2) + 1
    nn=nrow(tmp)
    if(nn>0) {
      if(index.return) 
        res.idx[counter+1:nn,] <- matrix(idx[[ichr]][tmp], ncol=2)
      bumps[counter+1:nn,] <- data.frame(chr=names(idx)[ichr], start=thispos[tmp[,1]],end=thispos[tmp[,2]])
      counter=counter+nn
    }
  }

  if(counter>0) {
    bumps <- bumps[1:counter,]
    bumps$length <- bumps$end - bumps$start + 1
    if(index.return) {
      res.idx <- res.idx[1:counter,,drop=FALSE]
      return(list(bumps=bumps, ix=res.idx))
    }
    else
      bumps
  }
  else {
    return(NULL)
  }
  
}
  
