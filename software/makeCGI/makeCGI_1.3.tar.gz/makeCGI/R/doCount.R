## read in sequence files and count C, G and CG for each bin
require(BSgenome)
count.CG <- function(.CGIoptions) {
  cat("count C and G in each bin:")
  if(.CGIoptions$rawdat.type=="txt") { ## text files for sequence, must in fa format
    rawfiles=dir("rawdata", pattern="fa$")
    nfiles=length(rawfiles)
    for(ifile in 1:nfiles) {
      fn=paste("rawdata/", rawfiles[ifile],sep="")
      ## read in file and make DNAString
      tmp=readLines(fn) #, what="character") ##, comment.char=">")
      ## find chr names
      idx=which(substr(tmp, 1,1)==">")
      chrs0 = substr(tmp[idx], 2, nchar(tmp[idx]))
      ## process the chrs a bit, because they are sometimes weird from FA files
      chrs = unlist(lapply(strsplit(chrs0, " "), function(x) x[[1]]))
      lineidx=c(idx, length(tmp)+1)
      for(ichr in 1:length(idx)) {
        chr =chrs[ichr]
        cat(chr, ",")
        tmp2=paste(tmp[(lineidx[ichr]+1):(lineidx[ichr+1]-1)], collapse="")
        Seq=DNAString(tmp2)
        ## save it
        save(Seq, file=paste(.CGIoptions$tmpDir,"/Seq-",chr,".rda",sep=""))
        ## count for every windowSize bp window
        Counts=do.Count(Seq, .CGIoptions$windowSize)
        ## save
        save(Counts, file=paste(.CGIoptions$CountsDir,"/Counts.",chr,".rda",sep=""))
      }
    }
  }

  else if(.CGIoptions$rawdat.type=="BSgenome") { ## from BSgenome package
    library(.CGIoptions$package,character=TRUE)
    dat=get(.CGIoptions$species)
    nchr=length(seqnames(dat))
    for(ichr in 1:nchr) {
      chr=seqnames(dat)[ichr]
      fn=paste(.CGIoptions$CountsDir,"/Counts.",chr,".rda",sep="")
      if(!file.exists(fn)) {
        if(class(dat[[ichr]]) == "DNAString")
           Seq=dat[[ichr]]
        else if(class(dat[[ichr]]) == "MaskedDNAString")
          Seq=unmasked(dat[[ichr]])
        else
          stop("Unknow sequence format\n")
        cat(chr, ",")
        ## count for every windowSize bp window
        Counts=do.Count(Seq, .CGIoptions$windowSize)
        ## save
        save(Counts, file=paste(.CGIoptions$CountsDir,"/Counts.",chr,".rda",sep=""))
      }
    }
  }
  cat("\n")
}

## Count number of C, G and CG for each L bp window
do.Count <- function(Seq, w) {
  X = c("CG", "C", "G", "N")
  XX = length(X)

  L = length(Seq)
  W = L%/%w   # number of whole windows
  L.w = L%%w  # L modulo w
  WW = W + ifelse(L.w == 0, 0, 1)
  counts = integer(WW*XX)
  dim(counts) = c(WW,XX)
  colnames(counts) = X
  counts[,XX] = as.integer(rep(w,WW))
  if (L.w != 0)
    counts[WW,XX] = as.integer(L%%w)
  for (j in seq(along=X)) {
    counts[,j] = bins(start(matchPattern(X[j], Seq)), WW, w)
  }
  counts
}

bins <- function(a, WW, w) {
  tabulate(a%/%w + ifelse(a%%w == 0, 0, 1), WW)
}
