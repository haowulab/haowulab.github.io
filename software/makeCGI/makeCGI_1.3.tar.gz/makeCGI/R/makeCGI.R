### make CGI list from posterior probabilities
annotateCGI <- function(.CGIoptions, cutoff.GCcontent, cutoff.CpG) {
  if(missing(cutoff.GCcontent))
    cutoff.GCcontent <- .CGIoptions$cutoff.GCcontent
  if(missing(cutoff.CpG))
    cutoff.CpG <-.CGIoptions$cutoff.CpG
  
  pp.files=dir(.CGIoptions$resultDir, patter="result", full.name=TRUE)
  if(length(pp.files)==0) {
    cat("No CGI for this species.\n")
    return(NULL)
  }
    
  cgi <- NULL
  for(i in 1:length(pp.files)) {
    load(pp.files[i])
    tmp <- annotateCGI.engine(.CGIoptions, result, cutoff.GCcontent, cutoff.CpG)
    if(!is.null(tmp))
      cgi <- base:::rbind(cgi, tmp)
    rm(result)
  }
  bumpsfile <- paste(.CGIoptions$resultDir, "/CGI-",.CGIoptions$species, ".rda",sep="")
  save(cgi, file=bumpsfile)
}


annotateCGI.engine <- function(.CGIoptions, result, cutoff.GCcontent, cutoff.CpG) {
  sep <- .CGIoptions$windowSize+1
  if(length(cutoff.GCcontent) == 1) 
    flag1 <- result[,"pp.GCcontent"]>cutoff.GCcontent
  else if(length(cutoff.GCcontent) == 2)
    flag1 <- result[,"pp.GCcontent"]>cutoff.GCcontent[1] & result[,"pp.GCcontent"]<=cutoff.GCcontent[2] 
  
  flag2 <- result[,"pp.CpG"]>cutoff.CpG
  flag <- flag1 & flag2
  flag[is.na(flag)] <- FALSE
  if(!any(flag))
    return(NULL)
  
  result <- result[flag,]
  ## find bumps
  bumps <- findBumps(result[,"chr"], result[,"pos"], rep(1, nrow(result)),0.95,
                     sep=sep, minlen=50, minCount=3, dis.merge=1)
  ## calculate the loglikelihood ratio for each CGI
  ## I'll think about this!!!
  
  cgi <- NULL
  if(nrow(bumps)>0) {
    ## locate the exact start/end position of CGI
    cgi <- trim.CGI(bumps, .CGIoptions$rawdat.type)
    ## add other information from cisgenome - skip it for now
  }
  cgi
}


### trim CGI using text
trim.CGI <- function(bumps0, format=c("txt","BSgenome")) {
  format <- match.arg(format)
  if(format=="BSgenome") {
    library(.CGIoptions$package,character=TRUE)
    dat=get(.CGIoptions$species)
  }  

  idx.throw=NULL
  ## init results
  cpgtable <- data.frame(bumps0, NA,NA,NA,NA)
  colnames(cpgtable) <- c("chr", "start", "end", "length",
                          "CpGcount", "GCcontent", "pctGC", "obsExp")

  idx=split(1:nrow(bumps0), bumps0[,"chr"])

  for(i in 1:length(idx)) { ## loop on chromosomes
    if(length(idx[[i]]) == 0)
      next
    chr=names(idx[i])
    cat(chr, ",")
    ## get sequence for this chromosome
    if(format=="txt")
      load(paste(.CGIoptions$tmpDir,"/Seq-",chr,".rda",sep=""))
    else {
      Seq=dat[[chr]]
      if(class(Seq)=="MaskedDNAString") ## drop the mask
        Seq <- unmasked(Seq)
    }        

    ## check whether cgi go beyond the boundary
    nn <- length(Seq)
    ncpg <- idx[[i]][length(idx[[i]])] ## location of last cgi for this chromosome
    if(cpgtable[ncpg,"end"] > nn)
      cpgtable[ncpg,"end"] <- nn
    ## for each bump on this chromosome
    for(ibump in idx[[i]]) {
      rr=(cpgtable[ibump,"start"]-1):(cpgtable[ibump,"end"]+1)
      if(rr[1]<0) rr[1] <- 1
      if(rr[length(rr)]>nn) rr[length(rr)] <- nn
      subseq <- Seq[rr]
      tmp <- matchPattern("CG",subseq)
      if(length(tmp)<3) {
        idx.throw <- c(idx.throw, ibump)
        next
      }
      ## true start/end
      start0 <- cpgtable[ibump,"start"]
      cpgtable[ibump,"start"] <- start0 + start(tmp)[1]-2
      cpgtable[ibump,"end"] <- start0 + end(tmp)[length(tmp)]-1
      cpgtable$length <- cpgtable$end-cpgtable$start+1
      ## add other information
      cpgtable[ibump, c("CpGcount","GCcontent", "pctGC", "obsExp")] <-
        add.GCinfo(Seq, cpgtable[ibump,"start"], cpgtable[ibump,"end"])
    }
  }

  if(!is.null(idx.throw)) ## throw away junk ones
    cpgtable <- cpgtable[-idx.throw,]

  cpgtable[cpgtable$CpGcount>3,]
}
