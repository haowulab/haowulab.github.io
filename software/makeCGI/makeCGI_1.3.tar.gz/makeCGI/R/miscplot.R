## functions to generate some misc checking plot

## make counts of CG/GC in each 256 bp window
calc.CGGC <- function(.CGIoptions, repeats) {
  L <- .CGIoptions$windowSize
  K <- round(256/L)
  CountFiles <- dir(.CGIoptions$CountsDir, pattern = "Count")
  CountFiles.full <- dir(.CGIoptions$CountsDir, pattern = "Count",full.names=TRUE)
  
  ## init results, I'll use 10 million counts at maximum
  ## (corresponds to 2.56 Gbp).
  nCGGC<- matrix(0, nrow=1e7, ncol=2)
  counter <- 0
  for(i in 1:length(CountFiles)) {
    chr <- strsplit(CountFiles[i], "\\.")[[1]][2]
    rpt.chr <- repeats[repeats$chr==chr, c("start", "end")]
    ## load the counts
    load(CountFiles.full[i])
    tmp <- Counts[,c(1:2,4)]
    tmp[,2] <- rowSums(Counts[,2:3])
    colnames(tmp)[2] <- "GC"
    dat <- collapse.data(tmp,K)
    ## remove repeats
    dat0 <- data.takerpt(dat, rpt.chr, N=256)$dat[,1:2]
    if(counter+nrow(dat0)>1e7) { ## reach the limit
      n0 <- 1e7-counter
      nCGGC[counter+(1:n0),] <- dat0[1:n0,]
      break
    }    else {
      nCGGC[counter+(1:nrow(dat0)),] <- dat0
      counter <- counter + nrow(dat0)
    }
  }
  nCGGC <- nCGGC[1:counter,]
  ## save the result
  save(nCGGC, file=paste(.CGIoptions$CountsDir, "/allCGGC-256bp.rda", sep=""))
}

miscplot <- function(.CGIoptions) {
  ## load in repeats
  repeats <- NULL
  rptfile <- paste("rawdata/repeats.rda")
  if(file.exists(rptfile)) { ## no file
    load(rptfile)
  }
  ff <- paste(.CGIoptions$CountsDir, "/allCGGC-256bp.rda", sep="")
  if(!file.exists(ff)) { ## make it
    calc.CGGC(.CGIoptions, repeats)
  }
  ## load in
  load(ff)
  ## start to make plots
  ## Figure 4 in paper: CpG rate in non-overlapping region of 256 bp
  CpGrate <- nCGGC[,1]/256
  tt <- table(round(CpGrate,digit=3))
  tt <- tt/sum(tt)
  save(tt, file="fig4.rda")
  ##names(tt)=round(as.integer(names(tt))/256,digits=2)
  pdf("hist-CpGrate.pdf", width=3.5, height=3.5, pointsize=10)
  barplot(tt[1:25]*100, xlab="CpG rate", ylab="Percentage", las=0)
  graphics.off()
  
  ## Figure 5 in paper: CpG rate in non-overlapping region of 256 bp
  ## stratified by GC-content. This seems need manual input on breaks
  ## but I'll try to make it reasonable.
  GCcontent <- nCGGC[,2]/256
  breaks <- c(0, seq(0.2,0.8, by=0.1),1)
  bins <- cut(GCcontent, breaks, include.lowest=TRUE)
  tt <- table(bins)
  nbins <- length(tt)
  ## combine if there are too few counts
  t0 <- tt[nbins]
  combine <- 1
  while(t0<200) {
    t0 <- t0 + tt[nbins-combine]
    combine <- combine+1
  }
  if(combine>1) {
    breaks <- c(breaks[1:(nbins-combine+1)], 1)
    bins <- cut(GCcontent, breaks, include.lowest=TRUE)
  }
  pdf("CpGrate-by-GC.pdf", width=3.5, height=6, pointsize=10)
  scale=NULL; scale$y$relation="free";
  a <- histogram(~CpGrate|bins, type="percent", scale=scale,col="lightgrey",
                 nint=100, ylab="", layout=c(1,length(breaks)-1),xlim=c(-0.01,0.23),
                 xlab="CpG rate", main="")
  print(a)
  graphics.off()
  ## figure 6b: density plots for GC-content in 256 bp window
#  den <- density(GCcontent)
  ## find CGI/nonCGI region for these segments - this is difficult

}

