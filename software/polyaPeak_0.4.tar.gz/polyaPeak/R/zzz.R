.First.lib <- function(lib, pkg) library.dynam("polyaPeak", pkg, lib)
