############################################
## get counts for peaks from bamfiles
############################################
getData.bam <- function(peaks, bamFiles, groups,winsize, candLen) {
  ## assume peaks is sorted!!!
  npeaks <- nrow(peaks)
  idx.ip=which(groups==1)
  idx.ct=which(groups==0)

  ## create GRanges from peaks, centered at summit
  ext=candLen/2+winsize/2
  ss=peaks$summit-ext
  ee=peaks$summit+ext-1
  allchrs=as.character(peaks$chr)
  allss=sapply(peaks$summit, function(x) seq(x-ext, x+ext-1, by=winsize))
  nbins.peak=candLen/winsize+1
  allseq=Rle(allchrs, rep(nbins.peak,nrow(peaks)))
  allrange=IRanges(start=allss, end=allss+winsize-1)
  peaks.GRanges1=GRanges(seqnames=allseq, ranges=allrange, strand=Rle("+",length(allseq)))
  peaks.GRanges0=GRanges(seqnames=allseq, ranges=allrange, strand=Rle("-",length(allseq)))

  ## create some background regions
  nbg=1000
  if(nbg>nrow(peaks))
    nbg=nrow(peaks)
  offset=5000
  idx=sample(nrow(peaks), nbg)
  ix=peaks$summit[idx]>offset+ext+1
  idx=idx[ix]
  nbg=length(idx)
  summit0=peaks$summit[idx]-offset
  allss0=sapply(summit0, function(x) seq(x-ext, x+ext-1, by=winsize))
  allseq0=Rle(allchrs[idx],rep(nbins.peak,length(idx)))
  allrange0=IRanges(start=allss0, end=allss0+winsize-1)
  bg.GRanges1=GRanges(seqnames=allseq0, ranges=allrange0, strand=Rle("+",length(allseq0)))
  bg.GRanges0=GRanges(seqnames=allseq0, ranges=allrange0, strand=Rle("-",length(allseq0)))
  
  ## read in bamfiles and create GRangs
  what <-c("rname", "strand", "pos", "qwidth") ## specifies field to read in
  param <- ScanBamParam(what = what)
  
  ## get IP/control counts and average IP+contorl coverages 
  cc=0
  bg.IP=bg.CT=matrix(0, ncol=2, nrow=length(bg.GRanges0))
  dat.IP=dat.CT=matrix(0, ncol=2, nrow=length(peaks.GRanges0))
  totCounts=rep(0,4)
  if(length(idx.ip) > 0) {
    for(i in idx.ip) {
      bam0 <- scanBam(bamFiles[i], param=param)[[1]]
      ## remove reads with NAs!!!
      ix=! (is.na(bam0[[1]]) | is.na(bam0[[2]]))
      bam=vector("list", length(bam0))
      names(bam)=names(bam0)
      for(k in 1:length(bam0))
        bam[[k]]=bam0[[k]][ix]
      totCounts[1]=totCounts[1]+sum(bam$strand=="+")
      totCounts[2]=totCounts[2]+sum(bam$strand=="-")
      ix.plus=bam$strand=="+"
      IRange.reads.1=GRanges(seqnames=Rle(bam$rname[ix.plus]),
        ranges=IRanges(bam$pos[ix.plus], width=1),
        strand=Rle("+",sum(ix.plus)))
      ix.minus=!ix.plus
      IRange.reads.0=GRanges(seqnames=Rle(bam$rname[ix.minus]),
        ranges=IRanges(bam$pos[ix.minus]+bam$qwidth[1], width=1),
        strand=Rle("-",sum(ix.minus)))
      ## get counts
      tmpdat1 <- countOverlaps(peaks.GRanges1, IRange.reads.1)
      tmpdat0 <- countOverlaps(peaks.GRanges0, IRange.reads.0)
      dat.IP[,1] <- dat.IP[,1]+tmpdat1
      dat.IP[,2] <- dat.IP[,2]+tmpdat0
      tmpdat1 <- countOverlaps(bg.GRanges1, IRange.reads.1)
      tmpdat0 <- countOverlaps(bg.GRanges0, IRange.reads.0)
      bg.IP[,1] <- bg.IP[,1]+tmpdat1
      bg.IP[,2] <- bg.IP[,2]+tmpdat0
    }
  } else {
    stop("No IP sample, cannot call peaks!\n")
  }
  if(length(idx.ct)>0) {
    for(i in idx.ct) {
      bam0 <- scanBam(bamFiles[i], param=param)[[1]]
      ix=! (is.na(bam0[[1]]) | is.na(bam0[[2]]))
      bam=vector("list", length(bam0))
      names(bam)=names(bam0)
      for(k in 1:length(bam0))
        bam[[k]]=bam0[[k]][ix]
      totCounts[3]=totCounts[3]+sum(bam$strand=="+")
      totCounts[4]=totCounts[4]+sum(bam$strand=="-")
      ix.plus=bam$strand=="+"
      IRange.reads.1=GRanges(seqnames=Rle(bam$rname[ix.plus]),
        ranges=IRanges(bam$pos[ix.plus], width=1),
        strand=Rle("+",sum(ix.plus)))
      ix.minus=!ix.plus
      IRange.reads.0=GRanges(seqnames=Rle(bam$rname[ix.minus]),
        ranges=IRanges(bam$pos[ix.minus]+bam$qwidth[1], width=1),
        strand=Rle("-",sum(ix.minus)))
      ## get counts
      tmpdat1 <- countOverlaps(peaks.GRanges1, IRange.reads.1)
      tmpdat0 <- countOverlaps(peaks.GRanges0, IRange.reads.0)
      dat.CT[,1] <- dat.CT[,1]+tmpdat1
      dat.CT[,2] <- dat.CT[,2]+tmpdat0
      tmpdat1 <- countOverlaps(bg.GRanges1, IRange.reads.1)
      tmpdat0 <- countOverlaps(bg.GRanges0, IRange.reads.0)
      bg.CT[,1] <- bg.CT[,1]+tmpdat1
      bg.CT[,2] <- bg.CT[,2]+tmpdat0
    }
  }
  
  ## rearrange data
  dat.peak <- rbind(matrix(dat.IP[,1], ncol=npeaks, byrow=FALSE), matrix(dat.IP[,2], ncol=npeaks, byrow=FALSE))
  if(length(idx.ct)>0) { 
    dat.peak <- rbind(dat.peak,
                      matrix(dat.CT[,1], ncol=npeaks, byrow=FALSE), matrix(dat.CT[,2], ncol=npeaks, byrow=FALSE))
  }

  dat.bg <- rbind(matrix(bg.IP[,1], ncol=nbg, byrow=FALSE), matrix(bg.IP[,2], ncol=nbg, byrow=FALSE))
  if(length(idx.ct)>0) { 
    dat.bg <- rbind(dat.bg,
                    matrix(bg.CT[,1], ncol=nbg, byrow=FALSE), matrix(bg.CT[,2], ncol=nbg, byrow=FALSE))
  }
##   dat.peak <- array(0, dim=c(nbins.peak,4, npeaks))
##   ipCounts <- ctCounts <- rep(0, npeaks)
##   ## rearrange
##   for(peakidx in 1:npeaks) {
##     ii <- ((peakidx-1)*nbins.peak+1):(peakidx*nbins.peak)
##     ipCounts[peakidx]=sum(dat.IP[ii,])
##     ctCounts[peakidx]=sum(dat.CT[ii,])
##     dat.peak[,1:2,peakidx]=dat.IP[ii,]
##     dat.peak[,3:4,peakidx]=dat.CT[ii,]
##   }
##   totCounts.peaks=ipCounts+ctCounts

  ## compute average coverage
  ##winCount0=mean.count(cc, sum(totCounts), candLen)
  winCount0=mean(colSums(dat.bg))
  list(dat.peak=dat.peak, dat.bg=dat.bg, totCounts=totCounts, winCount0=winCount0)
}

