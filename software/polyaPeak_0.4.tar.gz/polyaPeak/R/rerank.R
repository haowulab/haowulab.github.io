#################################################
## rerank peaks given peak list and BAM files
#################################################
rerank.peak <- function(peaks, bamFiles, groups, winsize=50, candLen=800) {
  ## sort peaks according to the score, if available
  if(!is.null(peaks$score)) {
    ix=sort(peaks$score, dec=T, index=T)$ix
    peaks=peaks[ix,]
  }
  ## get data
  cat("\nReading bam files ...\n")
  tmpdat <- getData.bam(peaks, bamFiles, groups, winsize, candLen)
  
  ## estimate peak shapes
  cat("Estimating polya distribution paramters ... \n")
  ntopPeaks <- min(1000, ncol(tmpdat$dat.peak))
  dat.topPeaks=tmpdat$dat.peak[,1:ntopPeaks]
  tmp = .Call("Kpolya", as.double(dat.topPeaks), as.integer(ncol(dat.topPeaks)),
      as.integer(nrow(dat.topPeaks)),as.integer(1))
  shape1 = tmp[[2]]

  ## estimate background shapes. 
  dat.bg = tmpdat$dat.bg
  tmp = .Call("Kpolya", as.double(dat.bg), as.integer(ncol(dat.bg)), as.integer(nrow(dat.bg)),as.integer(1))
  shape0 = tmp[[2]]
    
  ## estimate distributions for total counts
  NB.param=est.NB(colSums(dat.bg))
  a=0;   b=max(colSums(tmpdat$dat.peak))
  
  ## rerank all peaks
  cat("Reranking peaks ... \n")
  nallpeaks <- ncol(tmpdat$dat.peak)
  lrs=rep(0, nallpeaks)
  for(i in 1:nallpeaks) {
    lrs[i] = computeLR.peak.polya(tmpdat$dat.peak[,i],shape0, shape1, NB.param, a,b)
  }

  ## output reranked peaks with lr
  ix=sort(lrs, dec=TRUE, index=TRUE)$ix
  newpeaks=data.frame(peaks, lr=lrs)
  newpeaks=newpeaks[ix,]

  ## output shapes
  n0=2
  if(all(c(0,1) %in% groups)) n0=4
  shapes.bg = matrix(shape0, ncol=n0)
  shapes.peak= matrix(shape1, ncol=n0) 

  ## return
  list(peaks=newpeaks, shapes.peak=shapes.peak, shapes.bg=shapes.bg)
}

################################################
## compute LR for peaks based on polya model
################################################
computeLR.peak.polya <- function(dat, shape0, shape1, NB.param, a,b) {
  eps0=log(0.001)
  eps1=log(1-0.001)
  nbins=nrow(dat)
  totC=sum(dat)
  
  ## Pr(\sum X|Z=1) - Pr(\sum X|Z=0)
  p0.totC = dnbinom(totC, NB.param[1], NB.param[2], log=TRUE)
  p1.totC = log(b-a)
  p0.totC = Raddlog(p0.totC+eps1, p1.totC+eps0)
  p1.totC = Raddlog(p1.totC+eps0, p1.totC+eps1)
  lr.totC = p1.totC-p0.totC

  lr.X = lpolya(dat, shape1) - lpolya(dat, shape0)
  
  lr=lr.totC + lr.X
  lr
}
