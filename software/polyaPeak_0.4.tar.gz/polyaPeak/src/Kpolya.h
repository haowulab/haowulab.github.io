#include <math.h>
#include <stdlib.h>
#include <stdio.h>
#include <R.h>
#include <Rmath.h>
#include <R_ext/PrtUtil.h>
#include <Rinternals.h>
#include <Rdefines.h>
#include <R_ext/Rdynload.h>

#define MED_LINE_LENGTH 1024
#define PROC_SUCCESS 1

SEXP Kpolya(SEXP R_data, SEXP R_nGenes, SEXP R_nSamples, SEXP R_K);
double **arrange_2dmat(double *pt, int d1, int d2);

void SeqClust_Kpolya(int nGeneNum, int nSampleNum, double **vData,
				 int nK, int nMaxIter, double dTol,
				 double *BIC, double **vCA, double *vCP, double **vLike);

int SeqClust_Kpolya_MM(int nSampleNum, int nMMax, int nXMax,
                       double *vMHist, double **vXHist,
                       double *vAold, double *vAnew);

double SeqClust_Kpolya_MM_LogLike(int nSampleNum, int nMMax, int nXMax,
				  double *vMHist, double **vXHist, double *vA);


double gammaln(double dx);
