#include "Kpolya.h"

/* wrapper function */
SEXP Kpolya(SEXP R_data, SEXP R_nGenes, SEXP R_nSamples, SEXP R_K) {
	double *data=REAL(R_data);
	int K=INTEGER(R_K)[0];
	int nGenes=INTEGER(R_nGenes)[0];
	int nSamples=INTEGER(R_nSamples)[0];
	
	/* return variables */
	SEXP R_BIC, R_alpha, R_prior, R_postprob, result; 
	double *dBIC, *alpha, *prior, *postprob;
	PROTECT(R_BIC=allocVector(REALSXP, 1));
	PROTECT(R_alpha=allocVector(REALSXP, K*nSamples));
	PROTECT(R_prior=allocVector(REALSXP, K));
     PROTECT(R_postprob=allocVector(REALSXP, K*nGenes));

	dBIC=REAL(R_BIC);
	alpha=REAL(R_alpha);
	prior=REAL(R_prior);
	postprob=REAL(R_postprob);
	/* rearrange data */
	double **vData=arrange_2dmat(data, nGenes, nSamples);
	double **alpha_2d=arrange_2dmat(alpha, K, nSamples);
	double **postprob_2d=arrange_2dmat(postprob, nGenes, K);
	/* call engine */
	SeqClust_Kpolya(nGenes, nSamples, vData, K, 50, 1e-4, dBIC, alpha_2d, prior, postprob_2d); /*, "./","polya");*/
	
	PROTECT(result = allocVector(VECSXP, 4));
	SET_VECTOR_ELT(result, 0, R_BIC);
	SET_VECTOR_ELT(result, 1, R_alpha);
	SET_VECTOR_ELT(result, 2, R_prior);
     SET_VECTOR_ELT(result, 3, R_postprob);
	
	UNPROTECT(5);
	return(result);
	
}


double **arrange_2dmat(double *pt, int d1, int d2) {
	int i1;
	double **res;
	res=(double **)R_alloc(d1, sizeof(double *));
	for(i1=0; i1<d1; i1++) {
		res[i1] = pt + i1*d2;
	}
	return(res);
}


/* ----------------------------------------------------------------------- */ 
/*  SeqClust_Kpolya()                                                      */
/*  Model based clustering (K polya distributions)                         */
/* ----------------------------------------------------------------------- */ 
void SeqClust_Kpolya(int nGeneNum, int nSampleNum, double **vData, 
				 int nK, int nMaxIter, double dTol, 
				 double *BIC, double **vCA, double *vCP, double **vLike)
/*char strOutputPath[], char strOutputFile[])*/
{
	/* define */
	double dBIC = 0.0;
	
	double *vM = NULL;
	double *vMHist = NULL;
	double **vXHist = NULL;
	int nMMax = 0;
	int nXMax = 0;

	/*	double *vCP = NULL;
	  double **vCA = NULL; */
	
	double *vCPNew = NULL;
	double **vCANew = NULL;
	
	/*	double **vLike = NULL;*/
	double dLike = 0.0;
	double dLikeNew = 0.0;

	double dErr = 1e6;
	int nIter = 0;
	int nFinal = 0;

	int ni,nj,nk,nl;
	double dRand;

	double dLMax,dLSum,dRErr;

	FILE *fpOut;
	char strFileName[MED_LINE_LENGTH];

	/* Initialize */
	vM = (double *)calloc(nGeneNum, sizeof(double));
	GetRNGstate();
	if(vM == NULL)
	{
		error("SeqClust_Kpolya, cannot create memory for gene's total read count\n");
	}
	nMMax = 0;
	nXMax = 0;
	for(ni=0; ni<nGeneNum; ni++)
	{
		dLSum = 0.0;
		for(nj=0; nj<nSampleNum; nj++)
		{
			dLSum += vData[ni][nj];
			if((int)(vData[ni][nj]) > nXMax)
				nXMax = (int)(vData[ni][nj]);
		}
		if( (int)dLSum > nMMax)
			nMMax = (int)dLSum;
		vM[ni] = dLSum;
	}
	nMMax += 2;
	nXMax += 2;

	vMHist = (double *)calloc(nMMax, sizeof(double));
	if(vMHist == NULL)
	{
		error("SeqClust_Kpolya, cannot create histogram for gene's total read count\n");
	}
	vXHist = (double **)calloc(nXMax, sizeof(double *));
	if(vXHist == NULL)
	{
		error("SeqClust_Kpolya, cannot create histogram for gene's sample read count\n");
	}
	for(ni=0; ni<nXMax; ni++)
	{
		vXHist[ni] = (double *)calloc(nSampleNum, sizeof(double));
		if(vXHist[ni] == NULL)
		{
			error("SeqClust_Kpolya, cannot create histogram for gene's sample read count\n");
		}
	}

	/*vCP = (double *)calloc(nK, sizeof(double));*/
	vCPNew = (double *)calloc(nK, sizeof(double));
	if( vCPNew == NULL )
	{
		error("SeqClust_Kpolya, cannot create memory for prior probabilities of clusters\n");
	}
	for(ni=0; ni<nK; ni++)
	{
		vCP[ni] = 1.0/(double)nK;
		vCPNew[ni] = vCP[ni];
	}

	/*	vCA = (double **)calloc(nK, sizeof(double *));*/
	vCANew = (double **)calloc(nK, sizeof(double *));
	if( vCANew == NULL )
	{
		error("SeqClust_Kpolya, cannot create memory for cluster mean and variance\n");
	}
	for(ni=0; ni<nK; ni++)
	{
	  /*vCA[ni] = (double *)calloc(nSampleNum, sizeof(double));*/
		vCANew[ni] = (double *)calloc(nSampleNum, sizeof(double));
		if( vCANew[ni] == NULL )
		{
			error("SeqClust_Kpolya, cannot create memory for cluster mean and variance\n");
		}
		dRand = unif_rand();
		nk = (int)(dRand*nGeneNum);
		if(nk >= nGeneNum)
			nk = nGeneNum-1;
		if(nk < 0)
			nk = 0;
		
		dLSum = 0.0;
		for(nj=0; nj<nSampleNum; nj++)
		{
			dLSum += vData[nk][nj]+1;
		}

		for(nj=0; nj<nSampleNum; nj++)
		{
			vCA[ni][nj] = nSampleNum*(vData[nk][nj]+1)/dLSum;
			if(vCA[ni][nj]<0){
				int aaa=1;
			}
			vCANew[ni][nj] = vCA[ni][nj];
		}
	}

	/*	vLike = (double **)calloc(nGeneNum, sizeof(double *));
	if( vLike == NULL )
	{
		error("SeqClust_Kpolya, cannot create memory for computing likelihood\n");
	}
	for(ni=0; ni<nGeneNum; ni++)
	{
		vLike[ni] = (double *)calloc(nK, sizeof(double));
		if( vLike[ni] == NULL )
		{
			error("SeqClust_Kpolya, cannot create memory for computing likelihood\n");
		}
		}*/

	/* EM */
	for(nIter=0; nIter<nMaxIter; nIter++)
	{
		/* prepare parameter */
		for(nk=0; nk<nK; nk++)
		{
			vCPNew[nk] = log(vCP[nk]);
			dLSum = 0.0;
			for(nj=0; nj<nSampleNum; nj++)
			{
				dLSum += vCA[nk][nj];
				if(vCA[nk][nj]<=0)
					vCA[nk][nj]=0.000001;
				vCPNew[nk] -= gammaln(vCA[nk][nj]);
			}
			vCPNew[nk] = vCPNew[nk]+gammaln(dLSum);
			vCANew[nk][0] = dLSum;
		}

		/* compute likelihood & posterior */
		dLikeNew = 0.0;
		for(ni=0; ni<nGeneNum; ni++)
		{
			for(nk=0; nk<nK; nk++)
			{
				vLike[ni][nk] = vCPNew[nk];
				for(nj=0; nj<nSampleNum; nj++)
				{
					vLike[ni][nk] += gammaln(vData[ni][nj]+vCA[nk][nj]);
				}
				vLike[ni][nk] -= gammaln(vCANew[nk][0]+vM[ni]);

				if(nk == 0)
					dLMax = vLike[ni][nk];
				else if(vLike[ni][nk] > dLMax)
					dLMax = vLike[ni][nk];
			}

			dLSum = 0.0;
			for(nk=0; nk<nK; nk++)
			{
				vLike[ni][nk] = exp(vLike[ni][nk]-dLMax);
				dLSum += vLike[ni][nk];
			}

			dLikeNew += dLMax+log(dLSum);

			for(nk=0; nk<nK; nk++)
			{
				vLike[ni][nk] = vLike[ni][nk]/dLSum;
			}
		}

		if(nFinal == 1)
		{
			dLike = dLikeNew;
			break;
		}

		/* update parameters */
		for(nk=0; nk<nK; nk++)
		{
			vCPNew[nk] = 0.0;
			for(nj=0; nj<nSampleNum; nj++)
			{
				vCANew[nk][nj] = 0.0;
			}
		}

		/* update alpha */
		for(nk=0; nk<nK; nk++)
		{
			for(ni=0; ni<nMMax; ni++)
				vMHist[ni] = 0.0;
			for(ni=0; ni<nXMax; ni++)
				for(nj=0; nj<nSampleNum; nj++)
					vXHist[ni][nj] = 0.0;

			for(ni=0; ni<nGeneNum; ni++)
			{
				for(nl=0; nl<=(vM[ni]-0.9); nl++)
				{
					vMHist[nl] += vLike[ni][nk];
				}

				for(nj=0; nj<nSampleNum; nj++)
				{
					for(nl=0; nl<=(vData[ni][nj]-0.9); nl++)
					{
						vXHist[nl][nj] += vLike[ni][nk];
					}
				}
			}

			SeqClust_Kpolya_MM(nSampleNum, nMMax, nXMax, vMHist, vXHist, vCA[nk], vCANew[nk]);
		}

		/* update p */
		for(ni=0; ni<nGeneNum; ni++)
		{
			for(nk=0; nk<nK; nk++)
			{
				vCPNew[nk] += vLike[ni][nk];
			}
		}

		/* compute error */
		dErr = 0.0;
		for(nk=0; nk<nK; nk++)
		{
			vCPNew[nk] /= nGeneNum;
			dRErr = fabs( (vCPNew[nk]-vCP[nk])/(vCP[nk]+1e-6) );
			if(dRErr > dErr)
				dErr = dRErr;

			for(nj=0; nj<nSampleNum; nj++)
			{
				dRErr = fabs( (vCANew[nk][nj]-vCA[nk][nj])/(vCA[nk][nj]+1e-6) );
				if(dRErr > dErr)
					dErr = dRErr;
			}
		}

				
		/* evaluate stopping criteria */
		if(nIter > 0)
		{
			if(dLikeNew < dLike)
			{
				if( fabs(dLikeNew-dLike)/(dLike+1e-6) > 1e-6)
					warning("decreasing likelihood!\n");
				dLike = dLikeNew;
				break;
			}
		}

		if(dErr < dTol)
		{
			nFinal = 1;
			nIter--;
		}

		for(nk=0; nk<nK; nk++)
		{
			for(nj=0; nj<nSampleNum; nj++)
			{
				vCA[nk][nj] = vCANew[nk][nj];
			}
			vCP[nk] = vCPNew[nk];
			dLike = dLikeNew;
		}
	}

	PutRNGstate();

	/* Export results */
	/*	sprintf(strFileName, "%s%s.pp", strOutputPath, strOutputFile);
	fpOut = NULL;
	fpOut = fopen(strFileName, "w");
	if(fpOut == NULL)
	{
		error("SeqClust_Kpolya, cannot open output file!\n");
	}

	for(ni=0; ni<nGeneNum; ni++)
	{
		fprintf(fpOut, "%d", ni);
		for(nk=0; nk<nK; nk++)
		{
			fprintf(fpOut, "\t%f", vLike[ni][nk]); 
		}
		fprintf(fpOut, "\n");
	}
	fclose(fpOut);

	sprintf(strFileName, "%s%s.prior", strOutputPath, strOutputFile);
	fpOut = NULL;
	fpOut = fopen(strFileName, "w");
	if(fpOut == NULL)
	{
		error("SeqClust_Kpolya, cannot open output file!\n");
	}
	for(nk=0; nk<nK; nk++)
	{
		if(nk != 0)
			fprintf(fpOut, "\t");

		fprintf(fpOut, "%f", vCP[nk]); 
	}
	fprintf(fpOut, "\n");
	fclose(fpOut);

	sprintf(strFileName, "%s%s.alpha", strOutputPath, strOutputFile);
	fpOut = NULL;
	fpOut = fopen(strFileName, "w");
	if(fpOut == NULL)
	{
		error("SeqClust_Kpolya, cannot open output file!\n");
	}
	for(nk=0; nk<nK; nk++)
	{
		for(nj=0; nj<nSampleNum; nj++)
		{
			if(nj != 0)
				fprintf(fpOut, "\t");
			fprintf(fpOut, "%f", vCA[nk][nj]); 
		}
		fprintf(fpOut, "\n");
	}
	fclose(fpOut);
	*/
	/* Release memory */
	free(vM);
	free(vMHist);
	for(ni=0; ni<nXMax; ni++)
	{
		free(vXHist[ni]);
	}
	free(vXHist);

	/*	for(ni=0; ni<nGeneNum; ni++)
	{
		free(vLike[ni]);
	}
	free(vLike);
	free(vCP);*/
	free(vCPNew);
	for(ni=0; ni<nK; ni++)
	{
	  /*free(vCA[ni]);*/
		free(vCANew[ni]);
	}
	/*free(vCA);*/
	free(vCANew);
	
	/* return */
	dBIC = -2.0*dLike+(nK-1+nK*nSampleNum)*log((double)(nGeneNum*nSampleNum));
	/*printf(" iteration number = %d;  relative err = %f; BIC = %f \n", nIter, dErr, dBIC);*/
	BIC[0]=dBIC;
}


/* ----------------------------------------------------------------------- */ 
/*  SeqClust_Kpolya_MM()                                                   */
/*  MM algorithm for fitting polya distribution.                           */
/* ----------------------------------------------------------------------- */ 
int SeqClust_Kpolya_MM(int nSampleNum, int nMMax, int nXMax, 
		       double *vMHist, double **vXHist, 
		       double *vAold, double *vAnew)
{
	/* define */
	double *vA0 = NULL;
	double *vAmid1 = NULL;
	double *vAmid2 = NULL;
	double *vA1 = NULL;
	int nMaxIter = 1000;
	int ni,nj,nk;
	double dErr;
	double dS1,dS2;
	double dASum;
	double dI1,dI2;
	double dLike0,dLike1;
	int nAPositive;

	/* initialize */
	vA0 = (double *)calloc(nSampleNum, sizeof(double));
	vAmid1 = (double *)calloc(nSampleNum, sizeof(double));
	vAmid2 = (double *)calloc(nSampleNum, sizeof(double));
	vA1 = (double *)calloc(nSampleNum, sizeof(double));
	if( (vA0 == NULL) || (vAmid1 == NULL) || (vAmid2 == NULL) || (vA1 == NULL) )
	{
		printf("SeqClust_Kpolya_MM, cannot create memory for updating alpha!\n");
		exit(EXIT_FAILURE);
	}
	for(nj=0; nj<nSampleNum; nj++)
		vA0[nj] = vAold[nj];

	dLike0 = SeqClust_Kpolya_MM_LogLike(nSampleNum, nMMax, nXMax, vMHist, vXHist, vA0);
	
	/* MM */
	for(ni=0; ni<nMaxIter; ni++)
	{
		/* map 1*/
		dASum = 0.0;
		for(nj=0; nj<nSampleNum; nj++)
			dASum += vA0[nj];

		dS2 = 0.0;
		for(nk=0; nk<nMMax; nk++)
		{
			dS2 += vMHist[nk]/(dASum+nk);
		}

		for(nj=0; nj<nSampleNum; nj++)
		{
			dS1 = vXHist[0][nj];
			for(nk=1; nk<nXMax; nk++)
			{
				dS1 += vXHist[nk][nj]*vA0[nj]/(vA0[nj]+nk);
			}

			vAmid1[nj] = dS1/dS2;
		}

		/* map 2 */
		dASum = 0.0;
		for(nj=0; nj<nSampleNum; nj++)
			dASum += vAmid1[nj];

		dS2 = 0.0;
		for(nk=0; nk<nMMax; nk++)
		{
			dS2 += vMHist[nk]/(dASum+nk);
		}

		for(nj=0; nj<nSampleNum; nj++)
		{
			dS1 = vXHist[0][nj];
			for(nk=1; nk<nXMax; nk++)
			{
				dS1 += vXHist[nk][nj]*vAmid1[nj]/(vAmid1[nj]+nk);
			}
		
			vAmid2[nj] = dS1/dS2;
		}

		/* accelarator */
		dI1 = 0.0;
		dI2 = 0.0;
		for(nj=0; nj<nSampleNum; nj++)
		{
			vA1[nj] = vAmid1[nj]-vA0[nj];
			vAmid1[nj] = vAmid2[nj]-vAmid1[nj]-vA1[nj];
			dI1 += vA1[nj]*vA1[nj];
			dI2 += vA1[nj]*vAmid1[nj];
		}
		dI1 /= dI2;

		nAPositive = 1;
		for(nj=0; nj<nSampleNum; nj++)
		{
			vA1[nj] = vA0[nj]-2.0*dI1*vA1[nj]+dI1*dI1*vAmid1[nj];
			if(vA1[nj] < 0.0)
			{
				nAPositive = 0;
				break;
			}
		}
		
		if(nAPositive == 1)
		{
			dLike1 = SeqClust_Kpolya_MM_LogLike(nSampleNum, nMMax, nXMax, vMHist, vXHist, vA1);
		}
		else
		{
			dLike1 = dLike0 - 1.0;
		}

		if(dLike1 < dLike0)
		{
			for(nj=0; nj<nSampleNum; nj++)
				vA1[nj] = vAmid2[nj];

			dLike1 = SeqClust_Kpolya_MM_LogLike(nSampleNum, nMMax, nXMax, vMHist, vXHist, vA1);
		}

		dErr = fabs(dLike1-dLike0)/(fabs(dLike0)+1.0);

		if(dLike1 < dLike0)
		{
			if(dErr > 1e-6)
			{
				warning("SeqClust_Kpolya_MM, decreasing likelihood!\n");
			}
			break;
		}

		if(dErr < 1e-9)
			break;

		for(nj=0; nj<nSampleNum; nj++)
			vA0[nj] = vA1[nj];
		dLike0 = dLike1;
	}

	for(nj=0; nj<nSampleNum; nj++)
		vAnew[nj] = vA1[nj];

	/* release memory */
	free(vA0);
	free(vAmid1);
	free(vAmid2);
	free(vA1);

	/* return */
	return PROC_SUCCESS;
}

/* ----------------------------------------------------------------------- */ 
/*  SeqClust_Kpolya_MM_LogLike()                                           */
/*  Compute Polya loglikelihood for MM algorithm                           */
/* ----------------------------------------------------------------------- */ 
double SeqClust_Kpolya_MM_LogLike(int nSampleNum, int nMMax, int nXMax, 
				  double *vMHist, double **vXHist, double *vA)
{
	/* define */
	double dLike = 0.0;
	int ni,nj;
	double dASum;

	/* compute */
	dASum = 0.0;
	for(nj=0; nj<nSampleNum; nj++)
		dASum += vA[nj];

	for(ni=0; ni<nMMax; ni++)
		dLike -= vMHist[ni]*log(dASum+ni);
	for(ni=0; ni<nXMax; ni++)
	{
		for(nj=0; nj<nSampleNum; nj++)
		{
			dLike += vXHist[ni][nj]*log(vA[nj]+ni);
		}
	}

	/* return */
	return dLike;
}



/* ----------------------------------------------------------------------- */
/*                            lnGamma Function                             */
/* Return ln(gamma(dx)).                                                   */
/* ----------------------------------------------------------------------- */
double gammaln(double dx)
{
	double x,y,tmp,ser;
	static double cof[6]={76.18009172947146,
					  -86.50532032941677,
					  24.01409824083091,
					  -1.231739572450155,
					  0.1208650973866179e-2,
					  -0.5395239384953e-5};
	int j;
	
	if(dx<0.0)
		{
			error("gammaln(dx), dx must be greater than 0!\n");
		}
	y = dx;
	x = dx;
	tmp = x+5.5;
	tmp -= (x+0.5)*log(tmp);
	ser = 1.000000000190015;
	for(j=0; j<=5; j++)
		ser += cof[j]/++y;
	
	return -tmp+log(2.5066282746310005*ser/x);
}
